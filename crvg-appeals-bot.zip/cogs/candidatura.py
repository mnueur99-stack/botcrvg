import discord
from discord.ext import commands
from discord import app_commands
import datetime
import config


class FormularioModal(discord.ui.Modal, title="Formulário de Candidatura"):
    nickname = discord.ui.TextInput(
        label="Nickname",
        placeholder="Seu usuário do Roblox",
        max_length=50,
    )
    position = discord.ui.TextInput(
        label="Position",
        placeholder="Ex: Atacante, Meio-campo, Zagueiro, Goleiro…",
        max_length=50,
    )
    experience = discord.ui.TextInput(
        label="Experience",
        placeholder="Em quais ligas ou times você já jogou?",
        style=discord.TextStyle.paragraph,
        max_length=300,
    )
    turno = discord.ui.TextInput(
        label="Turno do dia",
        placeholder="Manhã, Tarde ou Noite",
        max_length=50,
    )

    async def on_submit(self, interaction: discord.Interaction):
        canal = interaction.guild.get_channel(config.CANDIDATURA_CHANNEL_ID)

        if not canal:
            await interaction.response.send_message(
                "❌ Canal de candidaturas não encontrado. Avise um administrador.",
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            color=config.COLOR_WHITE,
            timestamp=datetime.datetime.utcnow(),
        )
        embed.set_author(
            name=f"Nova Candidatura — {interaction.user.display_name}",
            icon_url=interaction.user.display_avatar.url,
        )
        embed.add_field(name="Nickname", value=str(self.nickname).strip(), inline=True)
        embed.add_field(name="Position", value=str(self.position).strip(), inline=True)
        embed.add_field(name="Turno do dia", value=str(self.turno).strip(), inline=True)
        embed.add_field(name="Experience", value=str(self.experience).strip(), inline=False)
        embed.set_footer(text=f"ID: {interaction.user.id} • {config.TEAM_NAME}")

        await canal.send(
            content=interaction.user.mention,
            embed=embed,
        )

        await interaction.response.send_message(
            "✅ Sua candidatura foi enviada com sucesso! Aguarde o retorno da nossa staff.",
            ephemeral=True,
        )


class Candidatura(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="candidatura", description="Enviar uma candidatura para entrar no time")
    async def candidatura(self, interaction: discord.Interaction):
        await interaction.response.send_modal(FormularioModal())


async def setup(bot: commands.Bot):
    await bot.add_cog(Candidatura(bot))
