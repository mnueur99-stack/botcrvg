import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import datetime
import config

DATA_FILE = os.path.join(os.path.dirname(__file__), "../data/tickets.json")


def load_data():
    if not os.path.exists(DATA_FILE):
        return {"active_tickets": {}, "counter": 0}
    with open(DATA_FILE, "r") as f:
        return json.load(f)


def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)


def is_staff(member: discord.Member) -> bool:
    return any(r.name in config.STAFF_ROLE_NAMES for r in member.roles)


class TicketTypeSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label=t["label"], emoji=t["emoji"], value=t["value"])
            for t in config.TICKET_TYPES
        ]
        super().__init__(
            placeholder="Selecione o motivo do seu ticket…",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        user = interaction.user
        ticket_type = self.values[0]
        type_label = next(
            t["label"] for t in config.TICKET_TYPES if t["value"] == ticket_type
        )

        data = load_data()

        for ch_id, info in data["active_tickets"].items():
            if info["user_id"] == user.id:
                ch = guild.get_channel(int(ch_id))
                if ch:
                    await interaction.followup.send(
                        f"Você já tem um ticket aberto: {ch.mention}", ephemeral=True
                    )
                    return

        category = discord.utils.get(guild.categories, name=config.TICKET_CATEGORY_NAME)
        if not category:
            category = await guild.create_category(config.TICKET_CATEGORY_NAME)

        data["counter"] += 1
        ticket_num = data["counter"]
        channel_name = f"ticket-{ticket_num:04d}-{user.name[:10].lower()}"

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, attach_files=True, embed_links=True
            ),
            guild.me: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, manage_channels=True
            ),
        }
        for role in guild.roles:
            if role.name in config.STAFF_ROLE_NAMES:
                overwrites[role] = discord.PermissionOverwrite(
                    view_channel=True, send_messages=True, attach_files=True
                )

        channel = await category.create_text_channel(channel_name, overwrites=overwrites)

        data["active_tickets"][str(channel.id)] = {
            "user_id": user.id,
            "user_name": str(user),
            "type": ticket_type,
            "type_label": type_label,
            "opened_at": datetime.datetime.utcnow().isoformat(),
            "ticket_num": ticket_num,
        }
        save_data(data)

        embed = discord.Embed(
            title=f"🎫 Ticket #{ticket_num:04d} — {type_label}",
            description=(
                f"Olá {user.mention}, obrigado por abrir um ticket!\n\n"
                "Por favor, descreva seu problema em detalhes e um membro da staff irá atendê-lo em breve.\n\n"
                "Use o botão abaixo para fechar este ticket quando o problema for resolvido."
            ),
            color=config.COLOR_PRIMARY,
            timestamp=datetime.datetime.utcnow(),
        )
        embed.set_footer(text=config.TEAM_NAME)

        view = TicketControlView()
        await channel.send(content=user.mention, embed=embed, view=view)
        await interaction.followup.send(
            f"✅ Seu ticket foi criado: {channel.mention}", ephemeral=True
        )


class TicketSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketTypeSelect())


class OpenTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Abrir Ticket", style=discord.ButtonStyle.primary, emoji="🎫", custom_id="open_ticket_btn")
    async def open_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        view = TicketSelectView()
        await interaction.response.send_message(
            "Por favor, selecione o motivo do seu ticket:", view=view, ephemeral=True
        )


class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Fechar Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="close_ticket_btn")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = interaction.channel
        data = load_data()

        if str(channel.id) not in data["active_tickets"]:
            await interaction.response.send_message("Este não é um canal de ticket ativo.", ephemeral=True)
            return

        info = data["active_tickets"][str(channel.id)]
        user = interaction.user

        ticket_owner = interaction.guild.get_member(info["user_id"])
        if user.id != info["user_id"] and not is_staff(user):
            await interaction.response.send_message("Apenas o dono do ticket ou a staff pode fechar este ticket.", ephemeral=True)
            return

        await interaction.response.defer()

        messages = []
        async for msg in channel.history(limit=500, oldest_first=True):
            if msg.author.bot:
                continue
            messages.append(f"[{msg.created_at.strftime('%Y-%m-%d %H:%M')}] {msg.author}: {msg.content}")

        transcript_text = "\n".join(messages) if messages else "Nenhuma mensagem."

        log_channel = discord.utils.get(interaction.guild.text_channels, name=config.TICKET_LOG_CHANNEL_NAME)
        if log_channel:
            log_embed = discord.Embed(
                title=f"🔒 Ticket #{info['ticket_num']:04d} Fechado",
                color=config.COLOR_ERROR,
                timestamp=datetime.datetime.utcnow(),
            )
            log_embed.add_field(name="Aberto por", value=f"<@{info['user_id']}> ({info['user_name']})", inline=True)
            log_embed.add_field(name="Tipo", value=info["type_label"], inline=True)
            log_embed.add_field(name="Fechado por", value=user.mention, inline=True)
            log_embed.add_field(name="Aberto em", value=info["opened_at"][:19].replace("T", " "), inline=True)
            transcript_file = discord.File(
                fp=__import__("io").BytesIO(transcript_text.encode()),
                filename=f"ticket-{info['ticket_num']:04d}-transcript.txt"
            )
            await log_channel.send(embed=log_embed, file=transcript_file)

        if ticket_owner:
            try:
                dm_embed = discord.Embed(
                    title=f"🔒 Seu ticket #{info['ticket_num']:04d} foi fechado",
                    description=f"Fechado por {user.mention}",
                    color=config.COLOR_ERROR,
                )
                await ticket_owner.send(embed=dm_embed)
            except discord.Forbidden:
                pass

        del data["active_tickets"][str(channel.id)]
        save_data(data)

        close_embed = discord.Embed(
            description="🔒 Este ticket foi fechado. O canal será deletado em 5 segundos.",
            color=config.COLOR_ERROR,
        )
        await channel.send(embed=close_embed)
        await discord.utils.sleep_until(
            datetime.datetime.utcnow() + datetime.timedelta(seconds=5)
        )
        await channel.delete(reason=f"Ticket fechado por {user}")

    @discord.ui.button(label="Adicionar Usuário", style=discord.ButtonStyle.secondary, emoji="➕", custom_id="add_user_ticket_btn")
    async def add_user(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_staff(interaction.user):
            await interaction.response.send_message("Apenas a staff pode adicionar usuários aos tickets.", ephemeral=True)
            return
        modal = AddUserModal()
        await interaction.response.send_modal(modal)


class AddUserModal(discord.ui.Modal, title="Adicionar Usuário ao Ticket"):
    user_id = discord.ui.TextInput(
        label="ID do Usuário ou @menção",
        placeholder="Digite o ID do usuário…",
        required=True,
    )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            uid = int(str(self.user_id).strip().replace("<@", "").replace(">", "").replace("!", ""))
            member = interaction.guild.get_member(uid) or await interaction.guild.fetch_member(uid)
            await interaction.channel.set_permissions(
                member,
                view_channel=True,
                send_messages=True,
                attach_files=True,
            )
            await interaction.response.send_message(f"✅ {member.mention} adicionado ao ticket.", ephemeral=False)
        except Exception:
            await interaction.response.send_message("❌ Não foi possível encontrar esse usuário.", ephemeral=True)


class Tickets(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="painel-tickets", description="Enviar o painel de tickets neste canal (apenas Staff)")
    @app_commands.default_permissions(administrator=True)
    async def ticket_panel(self, interaction: discord.Interaction):
        if not is_staff(interaction.user):
            await interaction.response.send_message("Você não tem permissão para isso.", ephemeral=True)
            return

        embed = discord.Embed(
            title=f"🎫 {config.TEAM_NAME} — Tickets de Suporte",
            description=config.TICKET_PANEL_DESCRIPTION,
            color=config.COLOR_TEAM,
        )
        embed.set_footer(text=config.TEAM_NAME)

        view = OpenTicketView()
        await interaction.channel.send(embed=embed, view=view)
        await interaction.response.send_message("✅ Painel de tickets enviado!", ephemeral=True)

    @app_commands.command(name="adicionar-ao-ticket", description="Adicionar um membro ao ticket atual (apenas Staff)")
    @app_commands.describe(member="O membro a ser adicionado")
    @app_commands.default_permissions(administrator=True)
    async def add_to_ticket(self, interaction: discord.Interaction, member: discord.Member):
        data = load_data()
        if str(interaction.channel.id) not in data["active_tickets"]:
            await interaction.response.send_message("Este não é um canal de ticket.", ephemeral=True)
            return
        await interaction.channel.set_permissions(member, view_channel=True, send_messages=True)
        await interaction.response.send_message(f"✅ {member.mention} adicionado ao ticket.")

    @app_commands.command(name="lista-tickets", description="Listar todos os tickets abertos (apenas Staff)")
    @app_commands.default_permissions(administrator=True)
    async def tickets_list(self, interaction: discord.Interaction):
        if not is_staff(interaction.user):
            await interaction.response.send_message("Você não tem permissão para isso.", ephemeral=True)
            return
        data = load_data()
        active = data["active_tickets"]
        if not active:
            await interaction.response.send_message("📭 Nenhum ticket aberto.", ephemeral=True)
            return
        embed = discord.Embed(title="📋 Tickets Abertos", color=config.COLOR_INFO)
        for ch_id, info in active.items():
            ch = interaction.guild.get_channel(int(ch_id))
            ch_mention = ch.mention if ch else f"<#{ch_id}>"
            embed.add_field(
                name=f"#{info['ticket_num']:04d} — {info['type_label']}",
                value=f"Usuário: <@{info['user_id']}>\nCanal: {ch_mention}\nAberto em: {info['opened_at'][:10]}",
                inline=False,
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Tickets(bot))
    bot.add_view(OpenTicketView())
    bot.add_view(TicketControlView())
