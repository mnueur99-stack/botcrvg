import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import datetime
import config

WARN_FILE = os.path.join(os.path.dirname(__file__), "../data/warnings.json")


def load_warnings():
    if not os.path.exists(WARN_FILE):
        return {}
    with open(WARN_FILE, "r") as f:
        return json.load(f)


def save_warnings(data):
    with open(WARN_FILE, "w") as f:
        json.dump(data, f, indent=2)


def is_mod(member: discord.Member) -> bool:
    return any(r.name in config.MOD_ROLE_NAMES for r in member.roles)


def mod_check(interaction: discord.Interaction) -> bool:
    return is_mod(interaction.user) or interaction.user.guild_permissions.administrator


class Moderation(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def send_mod_log(self, guild: discord.Guild, embed: discord.Embed):
        log_channel = discord.utils.get(guild.text_channels, name="logs-moderacao")
        if log_channel:
            try:
                await log_channel.send(embed=embed)
            except discord.Forbidden:
                pass

    # ──────────────────────────────── BANIR ────────────────────────────────

    @app_commands.command(name="banir", description="Banir um membro do servidor")
    @app_commands.describe(member="Membro a ser banido", reason="Motivo do banimento", delete_days="Dias de mensagens a deletar (0-7)")
    @app_commands.default_permissions(administrator=True)
    async def ban(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        reason: str = "Nenhum motivo informado",
        delete_days: app_commands.Range[int, 0, 7] = 0,
    ):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message("❌ Você não pode banir alguém com cargo igual ou superior.", ephemeral=True)
            return
        try:
            await member.send(
                embed=discord.Embed(
                    title=f"🔨 Você foi banido de {interaction.guild.name}",
                    description=f"**Motivo:** {reason}",
                    color=config.COLOR_ERROR,
                )
            )
        except discord.Forbidden:
            pass
        await member.ban(reason=f"{interaction.user}: {reason}", delete_message_days=delete_days)
        embed = discord.Embed(
            title="🔨 Membro Banido",
            color=config.COLOR_ERROR,
            timestamp=datetime.datetime.utcnow(),
        )
        embed.add_field(name="Usuário", value=f"{member} ({member.id})", inline=True)
        embed.add_field(name="Moderador", value=interaction.user.mention, inline=True)
        embed.add_field(name="Motivo", value=reason, inline=False)
        embed.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=embed)
        await self.send_mod_log(interaction.guild, embed)

    # ──────────────────────────────── DESBANIR ────────────────────────────────

    @app_commands.command(name="desbanir", description="Desbanir um usuário pelo ID")
    @app_commands.describe(user_id="ID do usuário a desbanir", reason="Motivo")
    @app_commands.default_permissions(administrator=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: str = "Nenhum motivo informado"):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        try:
            user = await self.bot.fetch_user(int(user_id))
            await interaction.guild.unban(user, reason=reason)
            embed = discord.Embed(title="✅ Membro Desbanido", color=config.COLOR_SUCCESS)
            embed.add_field(name="Usuário", value=f"{user} ({user.id})")
            embed.add_field(name="Moderador", value=interaction.user.mention)
            embed.add_field(name="Motivo", value=reason, inline=False)
            await interaction.response.send_message(embed=embed)
        except (ValueError, discord.NotFound, discord.HTTPException):
            await interaction.response.send_message("❌ Usuário não encontrado ou não está banido.", ephemeral=True)

    # ──────────────────────────────── EXPULSAR ────────────────────────────────

    @app_commands.command(name="expulsar", description="Expulsar um membro do servidor")
    @app_commands.describe(member="Membro a ser expulso", reason="Motivo da expulsão")
    @app_commands.default_permissions(administrator=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Nenhum motivo informado"):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message("❌ Você não pode expulsar alguém com cargo igual ou superior.", ephemeral=True)
            return
        try:
            await member.send(
                embed=discord.Embed(
                    title=f"👢 Você foi expulso de {interaction.guild.name}",
                    description=f"**Motivo:** {reason}",
                    color=config.COLOR_WARNING,
                )
            )
        except discord.Forbidden:
            pass
        await member.kick(reason=f"{interaction.user}: {reason}")
        embed = discord.Embed(title="👢 Membro Expulso", color=config.COLOR_WARNING, timestamp=datetime.datetime.utcnow())
        embed.add_field(name="Usuário", value=f"{member} ({member.id})", inline=True)
        embed.add_field(name="Moderador", value=interaction.user.mention, inline=True)
        embed.add_field(name="Motivo", value=reason, inline=False)
        embed.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=embed)
        await self.send_mod_log(interaction.guild, embed)

    # ──────────────────────────────── SILENCIAR ────────────────────────────────

    @app_commands.command(name="silenciar", description="Silenciar (timeout) um membro")
    @app_commands.describe(member="Membro a ser silenciado", minutos="Duração em minutos (máx. 40320 = 4 semanas)", reason="Motivo")
    @app_commands.default_permissions(administrator=True)
    async def timeout(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        minutos: app_commands.Range[int, 1, 40320] = 10,
        reason: str = "Nenhum motivo informado",
    ):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        if member.top_role >= interaction.user.top_role:
            await interaction.response.send_message("❌ Você não pode silenciar alguém com cargo igual ou superior.", ephemeral=True)
            return
        duration = datetime.timedelta(minutes=minutos)
        until = discord.utils.utcnow() + duration
        await member.timeout(until, reason=f"{interaction.user}: {reason}")
        hours, remainder = divmod(minutos, 60)
        duration_str = (f"{hours}h " if hours else "") + (f"{remainder}min" if remainder else "")
        embed = discord.Embed(title="⏳ Membro Silenciado", color=config.COLOR_WARNING, timestamp=datetime.datetime.utcnow())
        embed.add_field(name="Usuário", value=f"{member} ({member.id})", inline=True)
        embed.add_field(name="Moderador", value=interaction.user.mention, inline=True)
        embed.add_field(name="Duração", value=duration_str.strip(), inline=True)
        embed.add_field(name="Motivo", value=reason, inline=False)
        embed.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=embed)
        await self.send_mod_log(interaction.guild, embed)

    # ──────────────────────────────── DESSILENCIAR ────────────────────────────────

    @app_commands.command(name="dessilenciar", description="Remover silêncio de um membro")
    @app_commands.describe(member="Membro a ser dessilenciado", reason="Motivo")
    @app_commands.default_permissions(administrator=True)
    async def untimeout(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Nenhum motivo informado"):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        await member.timeout(None, reason=f"{interaction.user}: {reason}")
        embed = discord.Embed(title="✅ Silêncio Removido", color=config.COLOR_SUCCESS)
        embed.add_field(name="Usuário", value=member.mention)
        embed.add_field(name="Moderador", value=interaction.user.mention)
        await interaction.response.send_message(embed=embed)

    # ──────────────────────────────── ADVERTIR ────────────────────────────────

    @app_commands.command(name="advertir", description="Advertir um membro")
    @app_commands.describe(member="Membro a ser advertido", reason="Motivo da advertência")
    @app_commands.default_permissions(administrator=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        data = load_warnings()
        uid = str(member.id)
        if uid not in data:
            data[uid] = []
        data[uid].append({
            "reason": reason,
            "moderator": str(interaction.user),
            "moderator_id": interaction.user.id,
            "timestamp": datetime.datetime.utcnow().isoformat(),
        })
        save_warnings(data)
        warn_count = len(data[uid])
        try:
            await member.send(
                embed=discord.Embed(
                    title=f"⚠️ Advertência #{warn_count} em {interaction.guild.name}",
                    description=f"**Motivo:** {reason}",
                    color=config.COLOR_WARNING,
                )
            )
        except discord.Forbidden:
            pass
        embed = discord.Embed(
            title=f"⚠️ Membro Advertido (Advertência #{warn_count})",
            color=config.COLOR_WARNING,
            timestamp=datetime.datetime.utcnow(),
        )
        embed.add_field(name="Usuário", value=f"{member} ({member.id})", inline=True)
        embed.add_field(name="Moderador", value=interaction.user.mention, inline=True)
        embed.add_field(name="Motivo", value=reason, inline=False)
        embed.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=embed)
        await self.send_mod_log(interaction.guild, embed)

    # ──────────────────────────────── ADVERTENCIAS ────────────────────────────────

    @app_commands.command(name="advertencias", description="Ver advertências de um membro")
    @app_commands.describe(member="Membro a consultar")
    @app_commands.default_permissions(administrator=True)
    async def warnings(self, interaction: discord.Interaction, member: discord.Member):
        data = load_warnings()
        uid = str(member.id)
        warns = data.get(uid, [])
        if not warns:
            await interaction.response.send_message(f"✅ {member.mention} não possui advertências.", ephemeral=True)
            return
        embed = discord.Embed(
            title=f"⚠️ Advertências de {member.display_name}",
            color=config.COLOR_WARNING,
        )
        for i, w in enumerate(warns, 1):
            embed.add_field(
                name=f"Advertência #{i}",
                value=f"**Motivo:** {w['reason']}\n**Por:** {w['moderator']}\n**Data:** {w['timestamp'][:10]}",
                inline=False,
            )
        embed.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="limpar-advertencias", description="Limpar todas as advertências de um membro (apenas Staff)")
    @app_commands.describe(member="Membro para limpar as advertências")
    @app_commands.default_permissions(administrator=True)
    async def clearwarnings(self, interaction: discord.Interaction, member: discord.Member):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        data = load_warnings()
        uid = str(member.id)
        if uid in data:
            del data[uid]
            save_warnings(data)
        await interaction.response.send_message(f"✅ Advertências de {member.mention} limpas.", ephemeral=True)

    # ──────────────────────────────── LIMPAR MENSAGENS ────────────────────────────────

    @app_commands.command(name="limpar", description="Deletar um número de mensagens deste canal")
    @app_commands.describe(quantidade="Número de mensagens a deletar (1–100)")
    @app_commands.default_permissions(administrator=True)
    async def purge(self, interaction: discord.Interaction, quantidade: app_commands.Range[int, 1, 100] = 10):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=quantidade)
        await interaction.followup.send(f"✅ {len(deleted)} mensagem(ns) deletada(s).", ephemeral=True)

    # ──────────────────────────────── TRANCAR / DESTRANCAR ────────────────────────────────

    @app_commands.command(name="trancar", description="Trancar este canal para que apenas a staff possa falar")
    @app_commands.default_permissions(administrator=True)
    async def lock(self, interaction: discord.Interaction):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        await interaction.channel.set_permissions(interaction.guild.default_role, send_messages=False)
        embed = discord.Embed(description="🔒 Este canal foi **trancado**.", color=config.COLOR_ERROR)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="destrancar", description="Destrancar este canal")
    @app_commands.default_permissions(administrator=True)
    async def unlock(self, interaction: discord.Interaction):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        await interaction.channel.set_permissions(interaction.guild.default_role, send_messages=True)
        embed = discord.Embed(description="🔓 Este canal foi **destrancado**.", color=config.COLOR_SUCCESS)
        await interaction.response.send_message(embed=embed)

    # ──────────────────────────────── MODO LENTO ────────────────────────────────

    @app_commands.command(name="modo-lento", description="Definir modo lento para este canal")
    @app_commands.describe(segundos="Atraso em segundos (0 para desativar)")
    @app_commands.default_permissions(administrator=True)
    async def slowmode(self, interaction: discord.Interaction, segundos: app_commands.Range[int, 0, 21600] = 5):
        if not mod_check(interaction):
            await interaction.response.send_message("❌ Você não tem permissão.", ephemeral=True)
            return
        await interaction.channel.edit(slowmode_delay=segundos)
        msg = f"⏱ Modo lento definido para **{segundos}s**." if segundos > 0 else "⏱ Modo lento **desativado**."
        await interaction.response.send_message(msg)

    # ──────────────────────────────── INFO DO USUÁRIO ────────────────────────────────

    @app_commands.command(name="info-usuario", description="Ver informações sobre um membro")
    @app_commands.describe(member="Membro a consultar")
    @app_commands.default_permissions(administrator=True)
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        data = load_warnings()
        warn_count = len(data.get(str(member.id), []))
        roles = [r.mention for r in reversed(member.roles) if r != interaction.guild.default_role]
        embed = discord.Embed(
            title=f"👤 {member.display_name}",
            color=member.color if member.color.value else config.COLOR_INFO,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Usuário", value=str(member), inline=True)
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Bot", value="Sim" if member.bot else "Não", inline=True)
        embed.add_field(name="Entrou no Servidor", value=discord.utils.format_dt(member.joined_at, "R"), inline=True)
        embed.add_field(name="Conta criada em", value=discord.utils.format_dt(member.created_at, "R"), inline=True)
        embed.add_field(name="Advertências", value=str(warn_count), inline=True)
        if roles:
            embed.add_field(name=f"Cargos ({len(roles)})", value=" ".join(roles[:10]), inline=False)
        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
