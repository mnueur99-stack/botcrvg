import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import os
import sys
import logging
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("discord-bot")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True


class TeamBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=config.PREFIX,
            intents=intents,
            help_command=None,
        )

    async def setup_hook(self):
        data_dir = os.path.join(os.path.dirname(__file__), "data")
        os.makedirs(data_dir, exist_ok=True)

        cogs = ["cogs.fifa"]
        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"Cog carregado: {cog}")
            except Exception as e:
                logger.error(f"Falha ao carregar cog {cog}: {e}")

        try:
            synced = await self.tree.sync()
            logger.info(f"{len(synced)} comando(s) slash sincronizados")
        except Exception as e:
            logger.error(f"Falha ao sincronizar comandos: {e}")

    async def on_ready(self):
        logger.info(f"Conectado como {self.user} (ID: {self.user.id})")
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.playing,
                name="Cruz Maltino FIFA ⚽",
            )
        )

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        logger.error(f"Erro de comando: {error}")

    async def on_app_command_error(self, interaction: discord.Interaction, error: discord.app_commands.AppCommandError):
        msg = "❌ Ocorreu um erro. Por favor, tente novamente."
        if isinstance(error, discord.app_commands.MissingPermissions):
            msg = "❌ Você não tem permissão para usar este comando."
        elif isinstance(error, discord.app_commands.BotMissingPermissions):
            msg = f"❌ Estou sem permissões: `{', '.join(error.missing_permissions)}`"
        elif isinstance(error, discord.app_commands.CommandOnCooldown):
            msg = f"⏳ Aguarde {error.retry_after:.1f}s antes de usar este comando novamente."
        try:
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)
        except Exception:
            pass
        logger.error(f"Erro no comando /{interaction.command}: {error}")


START_TIME = time.time()


class UptimeHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/status":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            data = json.dumps({
                "status": "online",
                "uptime": round(time.time() - START_TIME),
                "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            })
            self.wfile.write(data.encode())
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write("🔥 Bot online e ativo 24/7".encode())

    def log_message(self, format, *args):
        pass


def run_uptime_server():
    port = int(os.environ.get("UPTIME_PORT", 3000))
    server = HTTPServer(("0.0.0.0", port), UptimeHandler)
    logger.info(f"Servidor de uptime rodando na porta {port}")
    server.serve_forever()


bot = TeamBot()


async def main():
    token = config.TOKEN
    if not token:
        logger.error("DISCORD_BOT_TOKEN não está definido. Adicione-o aos segredos do ambiente.")
        sys.exit(1)

    uptime_thread = threading.Thread(target=run_uptime_server, daemon=True)
    uptime_thread.start()

    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    asyncio.run(main())
