import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import datetime
import config

DATA_FILE = os.path.join(os.path.dirname(__file__), "../data/partidas.json")


def load_partidas():
    if not os.path.exists(DATA_FILE):
        return {"partidas": [], "counter": 0}
    with open(DATA_FILE, "r") as f:
        return json.load(f)


def save_partidas(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def get_partida_embed(p: dict, index: int = None) -> discord.Embed:
    status_emoji = {"agendada": "📅", "encerrada": "✅", "cancelada": "❌"}.get(p["status"], "📅")
    titulo = f"{status_emoji}  {config.TEAM_NAME} vs {p['adversario']}"
    cor = {
        "agendada": config.COLOR_TEAM,
        "encerrada": config.COLOR_SUCCESS,
        "cancelada": config.COLOR_ERROR,
    }.get(p["status"], config.COLOR_TEAM)

    embed = discord.Embed(title=titulo, color=cor)

    if index is not None:
        embed.set_footer(text=f"ID da partida: #{p['id']} • {config.TEAM_NAME}")
    else:
        embed.set_footer(text=config.TEAM_NAME)

    embed.add_field(name="📍 Local", value=p["local"], inline=True)
    embed.add_field(name="📆 Data", value=p["data"], inline=True)
    embed.add_field(name="🕐 Horário", value=p["horario"], inline=True)

    if p.get("descricao"):
        embed.add_field(name="📝 Observações", value=p["descricao"], inline=False)

    if p["status"] == "encerrada" and p.get("resultado"):
        r = p["resultado"]
        placar = f"**{r['gols_nos']} – {r['gols_adv']}**"
        desfecho = "✅ Vitória" if r["gols_nos"] > r["gols_adv"] else ("❌ Derrota" if r["gols_nos"] < r["gols_adv"] else "🤝 Empate")
        embed.add_field(name="Resultado", value=f"{placar}  •  {desfecho}", inline=False)
        if r.get("destaque"):
            embed.add_field(name="⭐ Destaque da Partida", value=r["destaque"], inline=False)

    if p["status"] == "cancelada" and p.get("motivo_cancelamento"):
        embed.add_field(name="Motivo do Cancelamento", value=p["motivo_cancelamento"], inline=False)

    return embed


class AgendarModal(discord.ui.Modal, title="Agendar Partida"):
    adversario = discord.ui.TextInput(label="Adversário", placeholder="Nome do time adversário")
    data = discord.ui.TextInput(label="Data", placeholder="ex: 25/06/2026")
    horario = discord.ui.TextInput(label="Horário", placeholder="ex: 20:00")
    local = discord.ui.TextInput(label="Local / Campo", placeholder="ex: Campo Principal - Roblox")
    descricao = discord.ui.TextInput(
        label="Observações (opcional)",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=300,
    )

    def __init__(self, ping_role: discord.Role = None, canal_anuncio: discord.TextChannel = None):
        super().__init__()
        self.ping_role = ping_role
        self.canal_anuncio = canal_anuncio

    async def on_submit(self, interaction: discord.Interaction):
        data = load_partidas()
        data["counter"] += 1
        partida = {
            "id": data["counter"],
            "adversario": str(self.adversario).strip(),
            "data": str(self.data).strip(),
            "horario": str(self.horario).strip(),
            "local": str(self.local).strip(),
            "descricao": str(self.descricao).strip(),
            "status": "agendada",
            "resultado": None,
            "motivo_cancelamento": None,
            "agendado_por": str(interaction.user),
            "agendado_em": datetime.datetime.utcnow().isoformat(),
        }
        data["partidas"].append(partida)
        save_partidas(data)

        embed = get_partida_embed(partida)
        embed.title = f"📅 Nova Partida Agendada — {config.TEAM_NAME} vs {partida['adversario']}"

        ping_text = self.ping_role.mention if self.ping_role else "@everyone"

        canal_destino = self.canal_anuncio or interaction.channel
        await canal_destino.send(content=f"🔔 {ping_text} — Nova partida agendada!", embed=embed)

        if canal_destino != interaction.channel:
            await interaction.response.send_message(
                f"✅ Partida **#{partida['id']}** agendada e anunciada em {canal_destino.mention}!", ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"✅ Partida **#{partida['id']}** agendada com sucesso!", ephemeral=True
            )


class ResultadoModal(discord.ui.Modal, title="Registrar Resultado"):
    partida_id = discord.ui.TextInput(label="ID da Partida", placeholder="ex: 1")
    gols_nos = discord.ui.TextInput(label="Gols do Nosso Time", placeholder="ex: 3", max_length=3)
    gols_adv = discord.ui.TextInput(label="Gols do Adversário", placeholder="ex: 1", max_length=3)
    destaque = discord.ui.TextInput(label="Destaque da Partida (opcional)", placeholder="Nome do jogador", required=False)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            pid = int(str(self.partida_id).strip())
            gn = int(str(self.gols_nos).strip())
            ga = int(str(self.gols_adv).strip())
        except ValueError:
            await interaction.response.send_message("❌ ID e gols devem ser números.", ephemeral=True)
            return

        data = load_partidas()
        partida = next((p for p in data["partidas"] if p["id"] == pid), None)

        if not partida:
            await interaction.response.send_message(f"❌ Partida #{pid} não encontrada.", ephemeral=True)
            return
        if partida["status"] == "cancelada":
            await interaction.response.send_message("❌ Essa partida foi cancelada.", ephemeral=True)
            return

        partida["status"] = "encerrada"
        partida["resultado"] = {
            "gols_nos": gn,
            "gols_adv": ga,
            "destaque": str(self.destaque).strip() or None,
        }
        save_partidas(data)

        embed = get_partida_embed(partida)
        embed.title = f"🏁 Resultado — {config.TEAM_NAME} vs {partida['adversario']}"
        await interaction.response.send_message(embed=embed)


class CancelarModal(discord.ui.Modal, title="Cancelar Partida"):
    partida_id = discord.ui.TextInput(label="ID da Partida", placeholder="ex: 1")
    motivo = discord.ui.TextInput(
        label="Motivo do Cancelamento",
        style=discord.TextStyle.paragraph,
        max_length=300,
    )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            pid = int(str(self.partida_id).strip())
        except ValueError:
            await interaction.response.send_message("❌ ID deve ser um número.", ephemeral=True)
            return

        data = load_partidas()
        partida = next((p for p in data["partidas"] if p["id"] == pid), None)

        if not partida:
            await interaction.response.send_message(f"❌ Partida #{pid} não encontrada.", ephemeral=True)
            return
        if partida["status"] != "agendada":
            await interaction.response.send_message("❌ Só é possível cancelar partidas agendadas.", ephemeral=True)
            return

        partida["status"] = "cancelada"
        partida["motivo_cancelamento"] = str(self.motivo).strip()
        save_partidas(data)

        embed = get_partida_embed(partida)
        embed.title = f"❌ Partida Cancelada — {config.TEAM_NAME} vs {partida['adversario']}"
        await interaction.response.send_message(embed=embed)


class Partidas(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ── Público ─────────────────────────────────────────────────────────────

    @app_commands.command(name="partidas", description="Ver as próximas partidas agendadas do time")
    async def partidas(self, interaction: discord.Interaction):
        data = load_partidas()
        agendadas = [p for p in data["partidas"] if p["status"] == "agendada"]

        if not agendadas:
            embed = discord.Embed(
                description="📭 Nenhuma partida agendada no momento.",
                color=config.COLOR_INFO,
            )
            await interaction.response.send_message(embed=embed)
            return

        embed = discord.Embed(
            title=f"📅 {config.TEAM_NAME} — Próximas Partidas",
            color=config.COLOR_TEAM,
        )
        for p in agendadas:
            valor = (
                f"📍 {p['local']}\n"
                f"📆 {p['data']}  🕐 {p['horario']}\n"
                f"ID: `#{p['id']}`"
            )
            if p.get("descricao"):
                valor += f"\n📝 {p['descricao']}"
            embed.add_field(
                name=f"vs {p['adversario']}",
                value=valor,
                inline=False,
            )
        embed.set_footer(text=config.TEAM_NAME)
        await interaction.response.send_message(embed=embed)

    # ── Administrador ────────────────────────────────────────────────────────

    @app_commands.command(name="agendar-partida", description="Agendar uma nova partida (apenas Administrador)")
    @app_commands.describe(
        cargo_ping="Cargo a ser mencionado no anúncio (opcional)",
        canal_anuncio="Canal onde o anúncio será enviado (opcional, padrão: canal atual)",
    )
    @app_commands.default_permissions(administrator=True)
    async def agendar_partida(
        self,
        interaction: discord.Interaction,
        cargo_ping: discord.Role = None,
        canal_anuncio: discord.TextChannel = None,
    ):
        modal = AgendarModal(ping_role=cargo_ping, canal_anuncio=canal_anuncio)
        await interaction.response.send_modal(modal)

    @app_commands.command(name="resultado", description="Registrar o resultado de uma partida (apenas Administrador)")
    @app_commands.default_permissions(administrator=True)
    async def resultado(self, interaction: discord.Interaction):
        await interaction.response.send_modal(ResultadoModal())

    @app_commands.command(name="cancelar-partida", description="Cancelar uma partida agendada (apenas Administrador)")
    @app_commands.default_permissions(administrator=True)
    async def cancelar_partida(self, interaction: discord.Interaction):
        await interaction.response.send_modal(CancelarModal())

    @app_commands.command(name="historico-partidas", description="Ver histórico de todas as partidas (apenas Administrador)")
    @app_commands.default_permissions(administrator=True)
    async def historico_partidas(self, interaction: discord.Interaction):
        data = load_partidas()
        todas = data["partidas"]
        if not todas:
            await interaction.response.send_message("Nenhuma partida registrada.", ephemeral=True)
            return

        encerradas = [p for p in todas if p["status"] == "encerrada"]
        vitorias = sum(1 for p in encerradas if p.get("resultado") and p["resultado"]["gols_nos"] > p["resultado"]["gols_adv"])
        derrotas = sum(1 for p in encerradas if p.get("resultado") and p["resultado"]["gols_nos"] < p["resultado"]["gols_adv"])
        empates = sum(1 for p in encerradas if p.get("resultado") and p["resultado"]["gols_nos"] == p["resultado"]["gols_adv"])

        embed = discord.Embed(
            title=f"📊 {config.TEAM_NAME} — Histórico de Partidas",
            color=config.COLOR_TEAM,
        )
        embed.add_field(name="✅ Vitórias", value=str(vitorias), inline=True)
        embed.add_field(name="❌ Derrotas", value=str(derrotas), inline=True)
        embed.add_field(name="🤝 Empates", value=str(empates), inline=True)
        embed.add_field(name="Total de Jogos", value=str(len(encerradas)), inline=True)

        recentes = [p for p in reversed(todas) if p["status"] == "encerrada"][:5]
        if recentes:
            linhas = []
            for p in recentes:
                r = p["resultado"]
                placar = f"{r['gols_nos']}–{r['gols_adv']}"
                emoji = "✅" if r["gols_nos"] > r["gols_adv"] else ("❌" if r["gols_nos"] < r["gols_adv"] else "🤝")
                linhas.append(f"{emoji} vs **{p['adversario']}** — {placar} ({p['data']})")
            embed.add_field(name="Últimos Resultados", value="\n".join(linhas), inline=False)

        embed.set_footer(text=config.TEAM_NAME)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="remover-partida", description="Remover permanentemente uma partida do histórico (apenas Administrador)")
    @app_commands.describe(partida_id="ID da partida a remover")
    @app_commands.default_permissions(administrator=True)
    async def remover_partida(self, interaction: discord.Interaction, partida_id: int):
        data = load_partidas()
        original = len(data["partidas"])
        data["partidas"] = [p for p in data["partidas"] if p["id"] != partida_id]
        if len(data["partidas"]) == original:
            await interaction.response.send_message(f"❌ Partida #{partida_id} não encontrada.", ephemeral=True)
            return
        save_partidas(data)
        await interaction.response.send_message(f"✅ Partida **#{partida_id}** removida do histórico.", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Partidas(bot))
