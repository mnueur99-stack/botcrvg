import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import datetime
import config

DATA_FILE = os.path.join(os.path.dirname(__file__), "../data/team.json")

DEFAULT_TEAM = {
    "name": config.TEAM_NAME,
    "description": "Um time competitivo de futebol no Roblox.",
    "founded": "2024",
    "division": "Divisão 1",
    "home_field": "A definir",
    "record": {"wins": 0, "losses": 0, "draws": 0},
    "roster": [],
    "tryout_info": "DMs abertas para pedidos de peneira. Abra um ticket para se candidatar.",
    "rules": [
        "Respeite todos os membros e a staff.",
        "Sem toxicidade, provocações ou condutas antidesportivas.",
        "Compareça aos treinos e partidas sempre que possível.",
        "Comunique ausências à staff com antecedência.",
        "Siga os Termos de Serviço do Roblox em todos os momentos.",
    ],
    "announcements": [],
}


def load_team():
    if not os.path.exists(DATA_FILE):
        save_team(DEFAULT_TEAM)
        return DEFAULT_TEAM
    with open(DATA_FILE, "r") as f:
        return json.load(f)


def save_team(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)


class AddPlayerModal(discord.ui.Modal, title="Adicionar Jogador ao Elenco"):
    roblox_username = discord.ui.TextInput(label="Usuário do Roblox", placeholder="NomeDoJogador123")
    discord_id = discord.ui.TextInput(label="ID do Discord (opcional)", placeholder="123456789", required=False)
    position = discord.ui.TextInput(label="Posição", placeholder="ex: Atacante, Meio-campo, Goleiro")
    jersey_number = discord.ui.TextInput(label="Número da Camisa", placeholder="10", max_length=3)
    notes = discord.ui.TextInput(label="Observações (opcional)", required=False, style=discord.TextStyle.short, max_length=100)

    async def on_submit(self, interaction: discord.Interaction):
        team = load_team()
        player = {
            "roblox": str(self.roblox_username).strip(),
            "discord_id": str(self.discord_id).strip() or None,
            "position": str(self.position).strip(),
            "number": str(self.jersey_number).strip(),
            "notes": str(self.notes).strip() or "",
            "added_at": datetime.datetime.utcnow().isoformat(),
        }
        team["roster"].append(player)
        save_team(team)
        await interaction.response.send_message(
            f"✅ **{player['roblox']}** adicionado ao elenco como #{player['number']} ({player['position']}).", ephemeral=True
        )


class AnnounceModal(discord.ui.Modal, title="Publicar Anúncio"):
    title_field = discord.ui.TextInput(label="Título", max_length=100)
    body = discord.ui.TextInput(label="Conteúdo do Anúncio", style=discord.TextStyle.paragraph, max_length=1000)

    async def on_submit(self, interaction: discord.Interaction):
        team = load_team()
        announcement = {
            "title": str(self.title_field).strip(),
            "body": str(self.body).strip(),
            "author": str(interaction.user),
            "timestamp": datetime.datetime.utcnow().isoformat(),
        }
        team["announcements"].insert(0, announcement)
        team["announcements"] = team["announcements"][:10]
        save_team(team)
        embed = discord.Embed(
            title=f"📢 {announcement['title']}",
            description=announcement["body"],
            color=config.COLOR_TEAM,
            timestamp=datetime.datetime.utcnow(),
        )
        embed.set_footer(text=f"Publicado por {announcement['author']} • {config.TEAM_NAME}")
        await interaction.response.send_message(embed=embed)


class TeamInfo(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="info-time", description="Ver informações gerais do time")
    @app_commands.default_permissions(administrator=True)
    async def teaminfo(self, interaction: discord.Interaction):
        team = load_team()
        rec = team["record"]
        total = rec["wins"] + rec["losses"] + rec["draws"]
        embed = discord.Embed(
            title=f"🏈 {team['name']}",
            description=team["description"],
            color=config.COLOR_TEAM,
        )
        embed.add_field(name="Fundado em", value=team["founded"], inline=True)
        embed.add_field(name="Divisão", value=team["division"], inline=True)
        embed.add_field(name="Campo Principal", value=team["home_field"], inline=True)
        embed.add_field(
            name="Campanha na Temporada",
            value=f"**{rec['wins']}V – {rec['losses']}D – {rec['draws']}E** ({total} jogos)",
            inline=False,
        )
        embed.add_field(name="Tamanho do Elenco", value=str(len(team["roster"])), inline=True)
        embed.set_footer(text=config.TEAM_NAME)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="elenco", description="Ver o elenco do time")
    @app_commands.default_permissions(administrator=True)
    async def roster(self, interaction: discord.Interaction):
        team = load_team()
        players = team["roster"]
        if not players:
            await interaction.response.send_message("O elenco está vazio no momento.", ephemeral=True)
            return
        by_position: dict[str, list] = {}
        for p in players:
            pos = p["position"]
            by_position.setdefault(pos, []).append(p)
        embed = discord.Embed(
            title=f"📋 {team['name']} — Elenco ({len(players)} jogadores)",
            color=config.COLOR_TEAM,
        )
        for position, group in by_position.items():
            lines = []
            for p in group:
                discord_mention = f" (<@{p['discord_id']}>)" if p.get("discord_id") else ""
                lines.append(f"**#{p['number']}** {p['roblox']}{discord_mention}")
            embed.add_field(name=position, value="\n".join(lines), inline=False)
        embed.set_footer(text=config.TEAM_NAME)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="peneira", description="Ver informações sobre peneiras")
    @app_commands.default_permissions(administrator=True)
    async def tryout(self, interaction: discord.Interaction):
        team = load_team()
        embed = discord.Embed(
            title=f"⚽ {team['name']} — Informações sobre Peneira",
            description=team["tryout_info"],
            color=config.COLOR_TEAM,
        )
        embed.set_footer(text="Abra um ticket para iniciar sua candidatura!")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="regras", description="Ver as regras do time")
    @app_commands.default_permissions(administrator=True)
    async def rules(self, interaction: discord.Interaction):
        team = load_team()
        rules_text = "\n".join(f"**{i}.** {r}" for i, r in enumerate(team["rules"], 1))
        embed = discord.Embed(
            title=f"📜 {team['name']} — Regras do Time",
            description=rules_text,
            color=config.COLOR_TEAM,
        )
        embed.set_footer(text="O descumprimento das regras pode resultar em punições.")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="historico", description="Ver o histórico de vitórias/derrotas/empates na temporada")
    @app_commands.default_permissions(administrator=True)
    async def record(self, interaction: discord.Interaction):
        team = load_team()
        rec = team["record"]
        total = rec["wins"] + rec["losses"] + rec["draws"]
        win_rate = f"{(rec['wins'] / total * 100):.1f}%" if total > 0 else "N/A"
        embed = discord.Embed(
            title=f"📊 {team['name']} — Histórico na Temporada",
            color=config.COLOR_TEAM,
        )
        embed.add_field(name="✅ Vitórias", value=str(rec["wins"]), inline=True)
        embed.add_field(name="❌ Derrotas", value=str(rec["losses"]), inline=True)
        embed.add_field(name="🤝 Empates", value=str(rec["draws"]), inline=True)
        embed.add_field(name="🎮 Total de Jogos", value=str(total), inline=True)
        embed.add_field(name="📈 Aproveitamento", value=win_rate, inline=True)
        embed.set_footer(text=config.TEAM_NAME)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="anuncios", description="Ver os anúncios recentes do time")
    @app_commands.default_permissions(administrator=True)
    async def announcements(self, interaction: discord.Interaction):
        team = load_team()
        ann = team["announcements"]
        if not ann:
            await interaction.response.send_message("Nenhum anúncio ainda.", ephemeral=True)
            return
        embed = discord.Embed(title=f"📢 {team['name']} — Anúncios Recentes", color=config.COLOR_TEAM)
        for a in ann[:5]:
            embed.add_field(
                name=a["title"],
                value=f"{a['body'][:200]}\n*{a['timestamp'][:10]} por {a['author']}*",
                inline=False,
            )
        await interaction.response.send_message(embed=embed)

    # ─── Comandos da Staff ───

    @app_commands.command(name="elenco-adicionar", description="Adicionar um jogador ao elenco (apenas Staff)")
    @app_commands.default_permissions(administrator=True)
    async def roster_add(self, interaction: discord.Interaction):
        await interaction.response.send_modal(AddPlayerModal())

    @app_commands.command(name="elenco-remover", description="Remover um jogador do elenco pelo usuário Roblox (apenas Staff)")
    @app_commands.describe(usuario_roblox="Usuário exato do Roblox a remover")
    @app_commands.default_permissions(administrator=True)
    async def roster_remove(self, interaction: discord.Interaction, usuario_roblox: str):
        team = load_team()
        original = len(team["roster"])
        team["roster"] = [p for p in team["roster"] if p["roblox"].lower() != usuario_roblox.lower()]
        if len(team["roster"]) == original:
            await interaction.response.send_message(f"❌ Jogador `{usuario_roblox}` não encontrado no elenco.", ephemeral=True)
            return
        save_team(team)
        await interaction.response.send_message(f"✅ **{usuario_roblox}** removido do elenco.", ephemeral=True)

    @app_commands.command(name="definir-historico", description="Atualizar o histórico da temporada (apenas Staff)")
    @app_commands.describe(vitorias="Vitórias", derrotas="Derrotas", empates="Empates")
    @app_commands.default_permissions(administrator=True)
    async def set_record(self, interaction: discord.Interaction, vitorias: int, derrotas: int, empates: int):
        team = load_team()
        team["record"] = {"wins": vitorias, "losses": derrotas, "draws": empates}
        save_team(team)
        await interaction.response.send_message(f"✅ Histórico atualizado: **{vitorias}V – {derrotas}D – {empates}E**", ephemeral=True)

    @app_commands.command(name="definir-info-time", description="Editar informações do time (apenas Staff)")
    @app_commands.describe(
        nome="Nome do time",
        descricao="Descrição do time",
        divisao="Divisão",
        campo="Nome do campo principal",
        fundado="Ano de fundação",
        peneira="Texto com informações sobre peneiras",
    )
    @app_commands.default_permissions(administrator=True)
    async def set_teaminfo(
        self,
        interaction: discord.Interaction,
        nome: str = None,
        descricao: str = None,
        divisao: str = None,
        campo: str = None,
        fundado: str = None,
        peneira: str = None,
    ):
        team = load_team()
        if nome:
            team["name"] = nome
        if descricao:
            team["description"] = descricao
        if divisao:
            team["division"] = divisao
        if campo:
            team["home_field"] = campo
        if fundado:
            team["founded"] = fundado
        if peneira:
            team["tryout_info"] = peneira
        save_team(team)
        await interaction.response.send_message("✅ Informações do time atualizadas.", ephemeral=True)

    @app_commands.command(name="anunciar", description="Publicar um anúncio do time (apenas Staff)")
    @app_commands.default_permissions(administrator=True)
    async def announce(self, interaction: discord.Interaction):
        await interaction.response.send_modal(AnnounceModal())

    @app_commands.command(name="adicionar-regra", description="Adicionar uma regra ao time (apenas Staff)")
    @app_commands.describe(regra="Texto da regra a adicionar")
    @app_commands.default_permissions(administrator=True)
    async def add_rule(self, interaction: discord.Interaction, regra: str):
        team = load_team()
        team["rules"].append(regra.strip())
        save_team(team)
        await interaction.response.send_message(f"✅ Regra adicionada: **{regra}**", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(TeamInfo(bot))
