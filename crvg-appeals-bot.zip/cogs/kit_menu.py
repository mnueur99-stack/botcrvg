import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import config

DATA_FILE = os.path.join(os.path.dirname(__file__), "../data/kits.json")

DEFAULT_KITS = {
    "casa": {
        "name": "Uniforme de Casa",
        "emoji": "🔵",
        "description": "O uniforme clássico usado nas partidas em casa.",
        "primary_color": "Azul",
        "secondary_color": "Branco",
        "details": "Camisa de manga curta com escudo do time. Disponível em P, M, G, GG.",
        "image_url": "",
        "kit_number": "1",
    },
    "fora": {
        "name": "Uniforme Visitante",
        "emoji": "⚪",
        "description": "O uniforme alternativo para jogos fora de casa.",
        "primary_color": "Branco",
        "secondary_color": "Azul",
        "details": "Design leve para maior conforto. Disponível em P, M, G, GG.",
        "image_url": "",
        "kit_number": "2",
    },
    "terceiro": {
        "name": "Terceiro Uniforme",
        "emoji": "⚫",
        "description": "Uniforme alternativo para ocasiões especiais.",
        "primary_color": "Preto",
        "secondary_color": "Dourado",
        "details": "Design edição limitada. Disponível em P, M, G, GG.",
        "image_url": "",
        "kit_number": "3",
    },
    "goleiro": {
        "name": "Uniforme de Goleiro",
        "emoji": "🧤",
        "description": "Uniforme exclusivo para os goleiros do time.",
        "primary_color": "Amarelo",
        "secondary_color": "Preto",
        "details": "Manga longa com cotovelos reforçados. Disponível em P, M, G, GG.",
        "image_url": "",
        "kit_number": "4",
    },
    "treino": {
        "name": "Uniforme de Treino",
        "emoji": "🏋️",
        "description": "Utilizado durante os treinos e aquecimentos.",
        "primary_color": "Cinza",
        "secondary_color": "Azul",
        "details": "Material respirável. Disponível em P, M, G, GG.",
        "image_url": "",
        "kit_number": "5",
    },
}


def load_kits():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w") as f:
            json.dump(DEFAULT_KITS, f, indent=2)
        return DEFAULT_KITS
    with open(DATA_FILE, "r") as f:
        return json.load(f)


def save_kits(kits):
    with open(DATA_FILE, "w") as f:
        json.dump(kits, f, indent=2)


def kit_embed(kit_data: dict) -> discord.Embed:
    embed = discord.Embed(
        title=f"{kit_data['emoji']}  {kit_data['name']}",
        description=kit_data["description"],
        color=config.COLOR_TEAM,
    )
    embed.add_field(name="Cor Principal", value=kit_data["primary_color"], inline=True)
    embed.add_field(name="Cor Secundária", value=kit_data["secondary_color"], inline=True)
    embed.add_field(name="Número do Uniforme", value=f"#{kit_data['kit_number']}", inline=True)
    embed.add_field(name="Detalhes", value=kit_data["details"], inline=False)
    if kit_data.get("image_url"):
        embed.set_image(url=kit_data["image_url"])
    embed.set_footer(text=config.TEAM_NAME)
    return embed


class KitSelect(discord.ui.Select):
    def __init__(self, kits: dict):
        self.kits = kits
        options = [
            discord.SelectOption(label=k["name"], emoji=k["emoji"], value=key, description=k["description"][:50])
            for key, k in kits.items()
        ][:25]
        super().__init__(placeholder="Escolha um uniforme para visualizar…", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        key = self.values[0]
        kit = self.kits[key]
        embed = kit_embed(kit)
        await interaction.response.edit_message(embed=embed, view=self.view)


class KitMenuView(discord.ui.View):
    def __init__(self, kits: dict):
        super().__init__(timeout=120)
        self.add_item(KitSelect(kits))


class AddKitModal(discord.ui.Modal, title="Adicionar / Editar Uniforme"):
    kit_key = discord.ui.TextInput(label="Chave do Uniforme (ID único, ex: casa)", placeholder="casa", max_length=30)
    kit_name = discord.ui.TextInput(label="Nome do Uniforme", placeholder="Uniforme de Casa")
    primary_color = discord.ui.TextInput(label="Cor Principal", placeholder="Azul")
    secondary_color = discord.ui.TextInput(label="Cor Secundária", placeholder="Branco")
    description = discord.ui.TextInput(label="Descrição", style=discord.TextStyle.paragraph, max_length=200)

    async def on_submit(self, interaction: discord.Interaction):
        kits = load_kits()
        key = str(self.kit_key).strip().lower().replace(" ", "_")
        existing = kits.get(key, {})
        kits[key] = {
            "name": str(self.kit_name).strip(),
            "emoji": existing.get("emoji", "👕"),
            "description": str(self.description).strip(),
            "primary_color": str(self.primary_color).strip(),
            "secondary_color": str(self.secondary_color).strip(),
            "details": existing.get("details", "Sem detalhes adicionais."),
            "image_url": existing.get("image_url", ""),
            "kit_number": existing.get("kit_number", str(len(kits) + 1)),
        }
        save_kits(kits)
        embed = kit_embed(kits[key])
        await interaction.response.send_message(f"✅ Uniforme **{kits[key]['name']}** salvo!", embed=embed, ephemeral=True)


class KitImageModal(discord.ui.Modal, title="Definir Imagem do Uniforme"):
    kit_key = discord.ui.TextInput(label="Chave do Uniforme", placeholder="casa")
    image_url = discord.ui.TextInput(label="URL da Imagem", placeholder="https://...", max_length=500)

    async def on_submit(self, interaction: discord.Interaction):
        kits = load_kits()
        key = str(self.kit_key).strip().lower()
        if key not in kits:
            await interaction.response.send_message(f"❌ Uniforme `{key}` não encontrado.", ephemeral=True)
            return
        kits[key]["image_url"] = str(self.image_url).strip()
        save_kits(kits)
        await interaction.response.send_message(f"✅ Imagem atualizada para **{kits[key]['name']}**.", ephemeral=True)


class KitMenu(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="uniformes", description="Visualizar todos os uniformes do time")
    @app_commands.default_permissions(administrator=True)
    async def kits(self, interaction: discord.Interaction):
        kits = load_kits()
        if not kits:
            await interaction.response.send_message("Nenhum uniforme cadastrado ainda.", ephemeral=True)
            return
        first_key = next(iter(kits))
        embed = kit_embed(kits[first_key])
        view = KitMenuView(kits)
        await interaction.response.send_message(
            content="Use o menu abaixo para visualizar os uniformes do time:", embed=embed, view=view
        )

    @app_commands.command(name="uniforme-adicionar", description="Adicionar ou editar um uniforme (apenas Staff)")
    @app_commands.default_permissions(administrator=True)
    async def kit_add(self, interaction: discord.Interaction):
        modal = AddKitModal()
        await interaction.response.send_modal(modal)

    @app_commands.command(name="uniforme-imagem", description="Definir a imagem de um uniforme (apenas Staff)")
    @app_commands.default_permissions(administrator=True)
    async def kit_image(self, interaction: discord.Interaction):
        modal = KitImageModal()
        await interaction.response.send_modal(modal)

    @app_commands.command(name="uniforme-remover", description="Remover um uniforme (apenas Staff)")
    @app_commands.describe(chave="A chave do uniforme a remover (ex: casa, fora)")
    @app_commands.default_permissions(administrator=True)
    async def kit_remove(self, interaction: discord.Interaction, chave: str):
        kits = load_kits()
        key = chave.strip().lower()
        if key not in kits:
            await interaction.response.send_message(f"❌ Uniforme `{key}` não encontrado.", ephemeral=True)
            return
        name = kits[key]["name"]
        del kits[key]
        save_kits(kits)
        await interaction.response.send_message(f"✅ Uniforme **{name}** removido.", ephemeral=True)

    @app_commands.command(name="uniforme-lista", description="Listar todas as chaves de uniformes")
    @app_commands.default_permissions(administrator=True)
    async def kit_list(self, interaction: discord.Interaction):
        kits = load_kits()
        if not kits:
            await interaction.response.send_message("Nenhum uniforme cadastrado.", ephemeral=True)
            return
        lines = [f"{k['emoji']} `{key}` — **{k['name']}**" for key, k in kits.items()]
        embed = discord.Embed(
            title=f"👕 {config.TEAM_NAME} — Lista de Uniformes",
            description="\n".join(lines),
            color=config.COLOR_TEAM,
        )
        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(KitMenu(bot))
