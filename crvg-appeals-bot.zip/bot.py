import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import os
import sys
import logging
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("discord-bot")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True


class TeamBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=config.PREFIX,
            intents=intents,
            help_command=None,
        )

    async def setup_hook(self):
        data_dir = os.path.join(os.path.dirname(__file__), "data")
        os.makedirs(data_dir, exist_ok=True)

        cogs = ["cogs.tickets", "cogs.kit_menu", "cogs.moderation", "cogs.team_info", "cogs.partidas", "cogs.candidatura"]
        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"Cog carregado: {cog}")
            except Exception as e:
                logger.error(f"Falha ao carregar cog {cog}: {e}")

        try:
            synced = await self.tree.sync()
            logger.info(f"{len(synced)} comando(s) slash sincronizados")
        except Exception as e:
            logger.error(f"Falha ao sincronizar comandos: {e}")

    async def on_ready(self):
        logger.info(f"Conectado como {self.user} (ID: {self.user.id})")
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name=f"{config.TEAM_NAME} | /ajuda",
            )
        )

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        logger.error(f"Erro de comando: {error}")

    async def on_app_command_error(self, interaction: discord.Interaction, error: discord.app_commands.AppCommandError):
        msg = "❌ Ocorreu um erro. Por favor, tente novamente."
        if isinstance(error, discord.app_commands.MissingPermissions):
            msg = "❌ Você não tem permissão para usar este comando."
        elif isinstance(error, discord.app_commands.BotMissingPermissions):
            msg = f"❌ Estou sem permissões: `{', '.join(error.missing_permissions)}`"
        elif isinstance(error, discord.app_commands.CommandOnCooldown):
            msg = f"⏳ Aguarde {error.retry_after:.1f}s antes de usar este comando novamente."
        try:
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)
        except Exception:
            pass
        logger.error(f"Erro no comando /{interaction.command}: {error}")


START_TIME = time.time()


class UptimeHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/status":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            data = json.dumps({
                "status": "online",
                "uptime": round(time.time() - START_TIME),
                "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            })
            self.wfile.write(data.encode())
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write("🔥 Bot online e ativo 24/7".encode())

    def log_message(self, format, *args):
        pass


def run_uptime_server():
    port = int(os.environ.get("UPTIME_PORT", 3000))
    server = HTTPServer(("0.0.0.0", port), UptimeHandler)
    logger.info(f"Servidor de uptime rodando na porta {port}")
    server.serve_forever()


bot = TeamBot()


@bot.tree.command(name="ajuda", description="Mostrar todos os comandos disponíveis do bot")
@app_commands.default_permissions(administrator=True)
async def help_command(interaction: discord.Interaction):
    embed = discord.Embed(
        title=f"📖 {config.TEAM_NAME} — Comandos",
        color=config.COLOR_TEAM,
    )

    embed.add_field(
        name="🎫 Tickets",
        value=(
            "`/painel-tickets` — Enviar painel de tickets (Staff)\n"
            "`/lista-tickets` — Ver tickets abertos (Staff)\n"
            "`/adicionar-ao-ticket` — Adicionar usuário ao ticket (Staff)"
        ),
        inline=False,
    )
    embed.add_field(
        name="👕 Uniformes",
        value=(
            "`/uniformes` — Visualizar uniformes do time\n"
            "`/uniforme-lista` — Listar chaves de uniformes\n"
            "`/uniforme-adicionar` — Adicionar/editar uniforme (Staff)\n"
            "`/uniforme-imagem` — Definir imagem do uniforme (Staff)\n"
            "`/uniforme-remover` — Remover uniforme (Staff)"
        ),
        inline=False,
    )
    embed.add_field(
        name="⚔️ Moderação",
        value=(
            "`/banir` `/desbanir` `/expulsar`\n"
            "`/silenciar` `/dessilenciar`\n"
            "`/advertir` `/advertencias` `/limpar-advertencias`\n"
            "`/limpar` `/trancar` `/destrancar` `/modo-lento`\n"
            "`/info-usuario`"
        ),
        inline=False,
    )
    embed.add_field(
        name="📋 Candidatura",
        value="`/candidatura` — Enviar formulário de candidatura ao time (todos)",
        inline=False,
    )
    embed.add_field(
        name="⚽ Partidas",
        value=(
            "`/partidas` — Ver próximas partidas (todos)\n"
            "`/agendar-partida` — Agendar nova partida\n"
            "`/resultado` — Registrar resultado\n"
            "`/cancelar-partida` — Cancelar partida\n"
            "`/historico-partidas` — Ver histórico completo\n"
            "`/remover-partida` — Remover partida do histórico"
        ),
        inline=False,
    )
    embed.add_field(
        name="🏈 Informações do Time",
        value=(
            "`/info-time` — Informações gerais\n"
            "`/elenco` — Elenco do time\n"
            "`/historico` — Histórico da temporada\n"
            "`/regras` — Regras do time\n"
            "`/peneira` — Informações sobre peneira\n"
            "`/anuncios` — Anúncios recentes\n"
            "`/anunciar` — Publicar anúncio (Staff)\n"
            "`/elenco-adicionar` `/elenco-remover` (Staff)\n"
            "`/definir-historico` `/definir-info-time` `/adicionar-regra` (Staff)"
        ),
        inline=False,
    )
    embed.set_footer(text=f"{config.TEAM_NAME} • Use /ajuda para ver esta lista a qualquer momento")
    await interaction.response.send_message(embed=embed)


async def main():
    token = config.TOKEN
    if not token:
        logger.error("DISCORD_BOT_TOKEN não está definido. Adicione-o aos segredos do ambiente.")
        sys.exit(1)

    uptime_thread = threading.Thread(target=run_uptime_server, daemon=True)
    uptime_thread.start()

    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    asyncio.run(main())
