import discord
from discord.ext import commands
from discord import app_commands
import random
import json
import os
import uuid
import asyncio
from datetime import datetime, timezone, timedelta

# ─── Caminhos ───────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(__file__)
DATA_PATH = os.path.join(BASE_DIR, "..", "data", "fifa_users.json")
IMAGES_PATH = os.path.join(BASE_DIR, "..", "data", "images")

# ─── Classes e valores ──────────────────────────────────────────────────────────
CLASS_EMOJIS = {
    "D": "⚪", "C": "🟢", "B": "🔵", "B+": "🟡",
    "A": "🟠", "A+": "🔴", "Icon": "🔥", "X": "🟣",
}
CLASS_VALUES = {
    "D": 50_000, "C": 100_000, "B": 200_000, "B+": 250_000,
    "A": 500_000, "A+": 750_000, "Icon": 1_000_000, "X": 1_500_000,
}
CLASS_WEIGHTS = {
    "D": 40, "C": 25, "B": 15, "B+": 10, "A": 6, "A+": 3, "Icon": 1, "X": 0,
}
BUYABLE_CLASSES = ["D", "C", "B", "B+"]

# ─── Recompensas diárias ─────────────────────────────────────────────────────────
DAILY_REWARDS = [50_000, 75_000, 100_000, 150_000, 200_000, 350_000, 500_000]

# ─── Formações 7v7 ──────────────────────────────────────────────────────────────
FORMATIONS = {
    "2-3-1":   ["GK", "CB1", "CB2", "CDM", "CM",  "CAM", "ST"],
    "3-2-1":   ["GK", "CB1", "CB2", "CB3", "CM",  "CAM", "ST"],
    "2-2-2":   ["GK", "CB1", "CB2", "CM",  "CAM", "RW",  "LW"],
    "1-3-2":   ["GK", "CB",  "CDM", "CM",  "CAM", "RW",  "LW"],
    "3-1-2":   ["GK", "CB1", "CB2", "CB3", "CDM", "RW",  "LW"],
    "2-1-2-1": ["GK", "CB1", "CB2", "CDM", "RW",  "LW",  "ST"],
    "1-2-2-1": ["GK", "CB",  "CDM", "CM",  "RW",  "LW",  "ST"],
}
SLOT_LABELS = {
    "GK":  "🥅 GK",  "CB":  "🛡️ CB",
    "CB1": "🛡️ CB1", "CB2": "🛡️ CB2", "CB3": "🛡️ CB3",
    "CDM": "⚙️ CDM", "CM":  "⚙️ CM",  "CAM": "🎯 CAM",
    "RW":  "↗️ RW",  "LW":  "↖️ LW",  "ST":  "⚡ ST",
}

# ─── Banco de jogadores ─────────────────────────────────────────────────────────
PLAYERS_DB = {
    # ── Classe A+ ────────────────────────────────────────────────────────────────
    "rapha": {
        "id": "rapha", "name": "Rapha", "class": "A+",
        "positions": ["RW", "ST"], "value": 750_000, "image": "rapha.png", "ovr": 89,
    },
    "kaka": {
        "id": "kaka", "name": "Kaka", "class": "A+",
        "positions": ["ST", "CM", "CB"], "value": 750_000, "image": "kaka.png", "ovr": 88,
    },
    "dudu": {
        "id": "dudu", "name": "Dudu", "class": "A+",
        "positions": ["LW", "ST"], "value": 750_000, "image": "dudu.png", "ovr": 89,
    },
    "espanhol": {
        "id": "espanhol", "name": "Espanhol", "class": "A+",
        "positions": ["ST", "CAM", "CM", "CB"], "value": 750_000, "image": "espanhol.png", "ovr": 87,
    },
    "daviseiji": {
        "id": "daviseiji", "name": "Davi Seiji", "class": "Icon",
        "positions": ["GK"], "value": 1_000_000, "image": "daviseiji.png", "ovr": 90,
    },
    # ── Classe A ─────────────────────────────────────────────────────────────────
    "felipe": {
        "id": "felipe", "name": "Felipe", "class": "A",
        "positions": ["GK"], "value": 500_000, "image": "felipe.png", "ovr": 87,
    },
    "danilo": {
        "id": "danilo", "name": "Danilo", "class": "A",
        "positions": ["CB", "CDM"], "value": 500_000, "image": "danilo.png", "ovr": 88,
    },
    "rafinhaxii": {
        "id": "rafinhaxii", "name": "Rafinhaxii", "class": "A",
        "positions": ["ST", "CAM", "CM", "CB"], "value": 500_000, "image": "rafinhaxii.png", "ovr": 86,
    },
    # ── Classe B+ ────────────────────────────────────────────────────────────────
    "top": {
        "id": "top", "name": "Top", "class": "B+",
        "positions": ["CDM", "CB", "CM"], "value": 250_000, "image": "top.png", "ovr": 86,
    },
    "sanga": {
        "id": "sanga", "name": "Sanga", "class": "B+",
        "positions": ["LW", "CM"], "value": 250_000, "image": "sanga.png", "ovr": 87,
    },
    "arthur": {
        "id": "arthur", "name": "Arthur", "class": "B+",
        "positions": ["ST", "CDM", "CB"], "value": 250_000, "image": "arthur.png", "ovr": 85,
    },
    "bungaz": {
        "id": "bungaz", "name": "Bungaz", "class": "B+",
        "positions": ["CB", "CDM"], "value": 250_000, "image": "bungaz.png", "ovr": 84,
    },
    "scar": {
        "id": "scar", "name": "Scar", "class": "Icon",
        "positions": ["CB"], "value": 1_000_000, "image": "scar.png", "ovr": 90,
    },
    "amond": {
        "id": "amond", "name": "Amond", "class": "B+",
        "positions": ["GK"], "value": 250_000, "image": "amond.png", "ovr": 86,
    },
    "gabriel": {
        "id": "gabriel", "name": "Gabriel Cremonez", "class": "B+",
        "positions": ["CAM", "CM", "CB"], "value": 250_000, "image": "gabriel.png", "ovr": 85,
    },
    "mobsx": {
        "id": "mobsx", "name": "Mobsx", "class": "B+",
        "positions": ["CB", "CM"], "value": 250_000, "image": "mobsx.png", "ovr": 84,
    },
    "pao": {
        "id": "pao", "name": "Pão", "class": "B+",
        "positions": ["GK", "CB"], "value": 250_000, "image": "pao.png", "ovr": 87,
    },
    "rick": {
        "id": "rick", "name": "Rick", "class": "B+",
        "positions": ["CDM", "CB", "CM"], "value": 250_000, "image": "rick.png", "ovr": 86,
    },
    "vini": {
        "id": "vini", "name": "Vini", "class": "B+",
        "positions": ["CB"], "value": 250_000, "image": "vini.png", "ovr": 85,
    },
    "arti": {
        "id": "arti", "name": "Arti", "class": "B+",
        "positions": ["ST", "CM"], "value": 250_000, "image": "arti.png", "ovr": 86,
    },
}

CLASS_DEFAULT_OVR = {
    "D": 60, "C": 69, "B": 76, "B+": 81, "A": 85, "A+": 90, "Icon": 95, "X": 99,
}

# ─── Dificuldades da IA ──────────────────────────────────────────────────────────
AI_DIFFICULTIES = {
    "facil":    {"name": "Fácil",    "emoji": "🟢", "ovr": 54,  "min_reward": 5_000,   "max_reward": 20_000},
    "medio":    {"name": "Médio",    "emoji": "🟡", "ovr": 65,  "min_reward": 25_000,  "max_reward": 60_000},
    "dificil":  {"name": "Difícil",  "emoji": "🟠", "ovr": 75,  "min_reward": 70_000,  "max_reward": 130_000},
    "expert":   {"name": "Expert",   "emoji": "🔴", "ovr": 84,  "min_reward": 150_000, "max_reward": 280_000},
    "lendario": {"name": "Lendário", "emoji": "🟣", "ovr": 92,  "min_reward": 300_000, "max_reward": 600_000},
}
AI_NAMES = [
    "Silva", "Costa", "Ferreira", "Santos", "Oliveira", "Lima",
    "Pereira", "Alves", "Rodrigues", "Martins", "Barbosa", "Souza",
    "Carvalho", "Araújo", "Nascimento", "Mendes", "Gomes", "Rocha",
]

PACK_COOLDOWN_SECONDS = 120
MATCH_COOLDOWN_SECONDS = 30

# ─── Fases da simulação ao vivo ──────────────────────────────────────────────────
MATCH_PHASES = [
    (0,  45, "🟩 1° Tempo — ⏱️ 45'"),
    (45, 90, "🟦 2° Tempo — ⏱️ 90'"),
]
LIVE_CHECKPOINTS = [15, 30, 45, 60, 75, 90]


# ─── Helpers de dados ────────────────────────────────────────────────────────────
def load_data() -> dict:
    os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
    if not os.path.exists(DATA_PATH):
        return {}
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_data(data: dict) -> None:
    os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
    with open(DATA_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def get_user(data: dict, user_id: str) -> dict:
    if user_id not in data:
        data[user_id] = {
            "balance": 0,
            "team_name": "Sem Nome",
            "stadium_name": "Sem Nome",
            "inventory": [],
            "formation": "2-3-1",
            "lineup": {},
            "captain": None,
            "last_pack": None,
            "last_match": None,
            "daily": {"streak": 0, "last_claimed": None, "strikes": 0},
        }
    for field in ["last_pack", "last_match"]:
        if field not in data[user_id]:
            data[user_id][field] = None
    return data[user_id]


def format_money(amount: int) -> str:
    if amount >= 1_000_000:
        return f"{amount / 1_000_000:.1f}M".replace(".0M", "M")
    if amount >= 1_000:
        return f"{amount // 1_000}k"
    return str(amount)


def get_player(pid: str) -> dict | None:
    return PLAYERS_DB.get(pid)


def pick_random_player() -> dict:
    players = list(PLAYERS_DB.values())
    weights = [CLASS_WEIGHTS[p["class"]] for p in players]
    return random.choices(players, weights=weights, k=1)[0]


def player_ovr(player_id: str) -> int:
    p = get_player(player_id)
    if not p:
        return 50
    return p.get("ovr", CLASS_DEFAULT_OVR.get(p["class"], 60))


def get_team_ovr(user: dict) -> int:
    slots = FORMATIONS.get(user.get("formation", "2-3-1"), [])
    lineup = user.get("lineup", {})
    total = 0
    for slot in slots:
        iid = lineup.get(slot)
        if iid:
            item = next((i for i in user["inventory"] if i["instance_id"] == iid), None)
            total += player_ovr(item["player_id"]) if item else 50
        else:
            total += 50
    return round(total / len(slots)) if slots else 50


def get_lineup_names(user: dict) -> dict[str, str]:
    slots = FORMATIONS.get(user.get("formation", "2-3-1"), [])
    lineup = user.get("lineup", {})
    result = {}
    for slot in slots:
        iid = lineup.get(slot)
        if iid:
            item = next((i for i in user["inventory"] if i["instance_id"] == iid), None)
            if item:
                p = get_player(item["player_id"])
                result[slot] = p["name"] if p else "?"
            else:
                result[slot] = "?"
        else:
            result[slot] = "*Vazio*"
    return result


def simulate_match(user_ovr: int, opp_ovr: int):
    total = user_ovr + opp_ovr
    user_chance = user_ovr / total
    events = []
    used: set[int] = set()
    for _ in range(random.randint(4, 10)):
        m = random.randint(1, 90)
        while m in used:
            m = random.randint(1, 90)
        used.add(m)
        events.append({"minuto": m, "time": "user" if random.random() < user_chance else "opp"})
    events.sort(key=lambda e: e["minuto"])
    u = sum(1 for e in events if e["time"] == "user")
    o = len(events) - u
    return u, o, events


def check_cooldown(user: dict, key: str, seconds: int) -> int | None:
    last = user.get(key)
    if not last:
        return None
    elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(last)).total_seconds()
    remaining = seconds - elapsed
    return int(remaining) if remaining > 0 else None


# ─── Simulação ao vivo (minuto a minuto) ─────────────────────────────────────────
async def run_live_match(
    interaction: discord.Interaction,
    user_team: str, opp_team: str,
    user_display: str, opp_display: str,
    user_ovr: int, opp_ovr: int,
    user_slots: dict, opp_slots: dict,
    events: list,
    user_formation: str, opp_formation: str,
    reward_line: str = "",
) -> tuple[int, int]:
    """
    Exibe a partida com atualizações ao vivo minuto a minuto.
    Retorna (user_goals, opp_goals).
    """
    u_names = [n for n in user_slots.values() if n != "*Vazio*"]
    o_names = [n for n in opp_slots.values() if n != "*Vazio*"]

    # Atribuir marcadores
    scored_events = []
    for ev in events:
        if ev["time"] == "user":
            scorer = random.choice(u_names) if u_names else "Jogador"
            scored_events.append({**ev, "scorer": scorer, "team": user_team})
        else:
            scorer = random.choice(o_names) if o_names else "Jogador"
            scored_events.append({**ev, "scorer": scorer, "team": opp_team})

    log: list[str] = ["🟢 **Jogo iniciado!**"]
    u_score = 0
    o_score = 0
    prev_min = 0

    def make_embed(phase_label: str, final: bool = False) -> discord.Embed:
        if final:
            won = u_score > o_score
            draw = u_score == o_score
            color = 0x00C851 if won else (0xFFD700 if draw else 0xFF4444)
            result_icon = "🏆 Vitória!" if won else ("🤝 Empate!" if draw else "💔 Derrota")
            title = f"🏟️ FIM DE JOGO — {result_icon}"
        else:
            color = 0x3498DB
            title = "🏟️ PARTIDA AO VIVO"

        embed = discord.Embed(title=title, color=color)
        embed.add_field(
            name="🔵 Seu Time",
            value=f"**{user_team}** ({user_display})\n`OVR {user_ovr}` · {user_formation}",
            inline=True,
        )
        embed.add_field(name="⚔️", value="\u200b", inline=True)
        embed.add_field(
            name="🔴 Adversário",
            value=f"**{opp_team}** ({opp_display})\n`OVR {opp_ovr}` · {opp_formation}",
            inline=True,
        )
        embed.add_field(
            name=f"📺 {phase_label}",
            value="\n".join(log[-18:]) or "—",
            inline=False,
        )
        embed.add_field(
            name="📊 Placar",
            value=f"**{user_team} {u_score} × {o_score} {opp_team}**",
            inline=False,
        )
        if final and reward_line:
            embed.add_field(name="💰 Recompensa", value=reward_line, inline=True)
        return embed

    checkpoints = [15, 30, 45, None, 60, 75, 90]
    halftime_done = False

    for cp in checkpoints:
        await asyncio.sleep(2)

        if cp is None:
            # Intervalo
            log.append(f"\n**⏸️ INTERVALO — {user_team} {u_score} × {o_score} {opp_team}**\n")
            halftime_done = True
            embed = make_embed("⏸️ Intervalo")
            await interaction.edit_original_response(embed=embed)
            continue

        from_min = prev_min
        for ev in scored_events:
            if from_min < ev["minuto"] <= cp:
                if ev["time"] == "user":
                    u_score += 1
                    log.append(f"`{ev['minuto']:02d}'` ⚽ **{ev['scorer']}** — {user_team}")
                else:
                    o_score += 1
                    log.append(f"`{ev['minuto']:02d}'` ⚽ **{ev['scorer']}** — {opp_team}")

        prev_min = cp
        if cp == 45 and not halftime_done:
            label = f"🟩 1° Tempo — ⏱️ {cp}'"
        elif cp > 45:
            label = f"🟦 2° Tempo — ⏱️ {cp}'"
        else:
            label = f"🟩 1° Tempo — ⏱️ {cp}'"

        embed = make_embed(label)
        await interaction.edit_original_response(embed=embed)

    # Mensagem final
    await asyncio.sleep(1.5)
    final_embed = make_embed("🏁 Apito Final", final=True)
    await interaction.edit_original_response(embed=final_embed)

    return u_score, o_score


# ─── Cog Principal ───────────────────────────────────────────────────────────────
class FIFA(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ── /pack ────────────────────────────────────────────────────────────────────
    @app_commands.command(name="pack", description="Abra um pack e receba um jogador! (cooldown: 2 min)")
    async def pack(self, interaction: discord.Interaction):
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        cd = check_cooldown(user, "last_pack", PACK_COOLDOWN_SECONDS)
        if cd:
            await interaction.response.send_message(
                f"⏳ Aguarde **{cd}s** para abrir outro pack!", ephemeral=True
            )
            return

        await interaction.response.defer()
        await asyncio.sleep(1.5)

        player = pick_random_player()
        iid = str(uuid.uuid4())
        user["inventory"].append({"instance_id": iid, "player_id": player["id"]})
        user["last_pack"] = datetime.now(timezone.utc).isoformat()
        save_data(data)

        cls = player["class"]
        embed = discord.Embed(title="🔥 PACK ABERTO! 🔥", color=0xFFD700)
        embed.add_field(name="🪪 Nome", value=f"**{player['name']}**", inline=False)
        embed.add_field(name="🏟️ Classe", value=f"{CLASS_EMOJIS[cls]} **{cls}**", inline=True)
        embed.add_field(name="⚽ Posição", value=" / ".join(player["positions"]), inline=True)
        embed.add_field(name="💶 Valor", value=format_money(player["value"]), inline=True)
        embed.add_field(name="⭐ OVR", value=str(player.get("ovr", CLASS_DEFAULT_OVR.get(cls, 60))), inline=True)
        embed.set_footer(text=f"Use /inventario • {interaction.user.display_name}")

        img = os.path.join(IMAGES_PATH, player.get("image", ""))
        if player.get("image") and os.path.exists(img):
            file = discord.File(img, filename=player["image"])
            embed.set_image(url=f"attachment://{player['image']}")
            await interaction.followup.send(embed=embed, file=file)
        else:
            await interaction.followup.send(embed=embed)

    # ── /inventario ──────────────────────────────────────────────────────────────
    @app_commands.command(name="inventario", description="Veja todos os jogadores que você possui")
    async def inventario(self, interaction: discord.Interaction):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))

        if not user["inventory"]:
            await interaction.followup.send("📦 Inventário vazio! Use `/pack` para começar.", ephemeral=True)
            return

        counts: dict[str, list] = {}
        for item in user["inventory"]:
            counts.setdefault(item["player_id"], []).append(item["instance_id"])

        lined_up = set(user["lineup"].values())
        captain = user["captain"]

        embed = discord.Embed(title=f"📦 Inventário — {interaction.user.display_name}", color=0x5865F2)
        embed.add_field(name="💳 Saldo", value=format_money(user["balance"]), inline=True)
        embed.add_field(name="👕 Time", value=user["team_name"], inline=True)
        embed.add_field(name="🏟️ Estádio", value=user["stadium_name"], inline=True)

        ovr_total = get_team_ovr(user)
        embed.add_field(name="⭐ OVR do Time", value=str(ovr_total), inline=True)
        embed.add_field(name="📋 Formação", value=user["formation"], inline=True)

        lines = []
        for pid, instances in counts.items():
            p = get_player(pid)
            if not p:
                continue
            count_str = f" ×{len(instances)}" if len(instances) > 1 else ""
            tags = []
            for iid in instances:
                if iid in lined_up:
                    slot = next((s for s, v in user["lineup"].items() if v == iid), "?")
                    tags.append(f"[{slot}]")
                if iid == captain:
                    tags.append("👑")
            tag_str = " ".join(tags)
            ovr = p.get("ovr", CLASS_DEFAULT_OVR.get(p["class"], 60))
            lines.append(
                f"{CLASS_EMOJIS[p['class']]} **{p['name']}**{count_str} · {'/'.join(p['positions'])} · OVR {ovr} · {format_money(p['value'])} {tag_str}"
            )

        embed.add_field(name=f"🎴 Jogadores ({len(user['inventory'])})", value="\n".join(lines) or "—", inline=False)
        embed.set_footer(text="Use /escalacao para ver sua escalação")
        await interaction.followup.send(embed=embed)

    # ── /escalacao ───────────────────────────────────────────────────────────────
    @app_commands.command(name="escalacao", description="Veja sua escalação atual no 7v7")
    async def escalacao(self, interaction: discord.Interaction):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))

        slots = FORMATIONS.get(user["formation"], [])
        captain = user["captain"]
        embed = discord.Embed(
            title=f"⚽ Escalação — {user['team_name']}",
            description=f"**Formação:** {user['formation']} | **OVR:** {get_team_ovr(user)} | **Estádio:** {user['stadium_name']}",
            color=0x00C851,
        )
        lines = []
        for slot in slots:
            label = SLOT_LABELS.get(slot, slot)
            iid = user["lineup"].get(slot)
            if iid:
                item = next((i for i in user["inventory"] if i["instance_id"] == iid), None)
                p = get_player(item["player_id"]) if item else None
                pname = p["name"] if p else "?"
                cap = " 👑" if iid == captain else ""
                lines.append(f"{label}: **{pname}**{cap}")
            else:
                lines.append(f"{label}: *Vazio*")

        filled = sum(1 for s in slots if s in user["lineup"])
        embed.add_field(name="📋 Titulares", value="\n".join(lines) or "—", inline=False)
        embed.set_footer(text=f"{filled}/{len(slots)} posições preenchidas")
        await interaction.followup.send(embed=embed)

    # ── Autocomplete helpers ─────────────────────────────────────────────────────
    async def _inv_ac(self, interaction: discord.Interaction, current: str):
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        lined = set(user["lineup"].values())
        choices, seen = [], set()
        for item in user["inventory"]:
            p = get_player(item["player_id"])
            if not p:
                continue
            label = f"{CLASS_EMOJIS[p['class']]} {p['name']} ({'/'.join(p['positions'])}) OVR {p.get('ovr','?')}"
            if item["instance_id"] in lined:
                label += " [Escalado]"
            if current.lower() in label.lower() and label not in seen:
                seen.add(label)
                choices.append(app_commands.Choice(name=label[:100], value=item["instance_id"]))
            if len(choices) >= 25:
                break
        return choices

    async def _lineup_ac(self, interaction: discord.Interaction, current: str):
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        choices = []
        for slot, iid in user["lineup"].items():
            item = next((i for i in user["inventory"] if i["instance_id"] == iid), None)
            p = get_player(item["player_id"]) if item else None
            label = f"{SLOT_LABELS.get(slot, slot)}: {p['name'] if p else '?'}"
            if current.lower() in label.lower():
                choices.append(app_commands.Choice(name=label[:100], value=iid))
        return choices

    async def _slot_ac(self, interaction: discord.Interaction, current: str):
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        slots = FORMATIONS.get(user["formation"], [])
        choices = []
        for slot in slots:
            label = SLOT_LABELS.get(slot, slot)
            if slot in user["lineup"]:
                item = next((i for i in user["inventory"] if i["instance_id"] == user["lineup"][slot]), None)
                p = get_player(item["player_id"]) if item else None
                label += f" (atual: {p['name'] if p else '?'})"
            if current.lower() in label.lower():
                choices.append(app_commands.Choice(name=label[:100], value=slot))
        return choices

    async def _dupli_ac(self, interaction: discord.Interaction, current: str):
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        counts: dict[str, int] = {}
        for item in user["inventory"]:
            counts[item["player_id"]] = counts.get(item["player_id"], 0) + 1
        choices = []
        for pid, qty in counts.items():
            if qty <= 1:
                continue
            p = get_player(pid)
            if not p:
                continue
            label = f"{CLASS_EMOJIS[p['class']]} {p['name']} — {qty} cópias (vender {qty-1}× por {format_money(p['value']//2)} cada)"
            if current.lower() in label.lower():
                choices.append(app_commands.Choice(name=label[:100], value=pid))
        return choices[:25]

    async def _buyable_ac(self, interaction: discord.Interaction, current: str):
        choices = []
        for p in PLAYERS_DB.values():
            if p["class"] not in BUYABLE_CLASSES:
                continue
            label = f"{CLASS_EMOJIS[p['class']]} {p['name']} ({'/'.join(p['positions'])}) — {format_money(p['value'])}"
            if current.lower() in label.lower():
                choices.append(app_commands.Choice(name=label[:100], value=p["id"]))
        return choices[:25]

    # ── /escalarjogador ──────────────────────────────────────────────────────────
    @app_commands.command(name="escalarjogador", description="Escale um jogador na sua formação")
    @app_commands.describe(jogador="Jogador do inventário", posicao="Slot na formação")
    @app_commands.autocomplete(jogador=_inv_ac, posicao=_slot_ac)
    async def escalar_jogador(self, interaction: discord.Interaction, jogador: str, posicao: str):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))

        if jogador not in [i["instance_id"] for i in user["inventory"]]:
            await interaction.followup.send("❌ Jogador não encontrado no inventário.", ephemeral=True)
            return
        if posicao not in FORMATIONS.get(user["formation"], []):
            await interaction.followup.send(f"❌ Posição inválida para **{user['formation']}**.", ephemeral=True)
            return
        for s, iid in user["lineup"].items():
            if iid == jogador and s != posicao:
                await interaction.followup.send(f"❌ Jogador já escalado em **{SLOT_LABELS.get(s, s)}**.", ephemeral=True)
                return

        user["lineup"][posicao] = jogador
        save_data(data)
        item = next(i for i in user["inventory"] if i["instance_id"] == jogador)
        p = get_player(item["player_id"])
        await interaction.followup.send(f"✅ **{p['name']}** escalado em **{SLOT_LABELS.get(posicao, posicao)}**! OVR do time: {get_team_ovr(user)}")

    # ── /removerjogador ──────────────────────────────────────────────────────────
    @app_commands.command(name="removerjogador", description="Remova um jogador da escalação")
    @app_commands.describe(jogador="Jogador escalado a remover")
    @app_commands.autocomplete(jogador=_lineup_ac)
    async def remover_jogador(self, interaction: discord.Interaction, jogador: str):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))

        slot = next((s for s, iid in user["lineup"].items() if iid == jogador), None)
        if not slot:
            await interaction.followup.send("❌ Jogador não está na escalação.", ephemeral=True)
            return

        del user["lineup"][slot]
        if user["captain"] == jogador:
            user["captain"] = None
        save_data(data)

        item = next((i for i in user["inventory"] if i["instance_id"] == jogador), None)
        p = get_player(item["player_id"]) if item else None
        await interaction.followup.send(f"✅ **{p['name'] if p else 'Jogador'}** removido de **{SLOT_LABELS.get(slot, slot)}**.")

    # ── /escolhercapitao ─────────────────────────────────────────────────────────
    @app_commands.command(name="escolhercapitao", description="Escolha o capitão do time (deve estar escalado)")
    @app_commands.describe(jogador="Jogador escalado para ser capitão")
    @app_commands.autocomplete(jogador=_lineup_ac)
    async def escolher_capitao(self, interaction: discord.Interaction, jogador: str):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))

        if jogador not in user["lineup"].values():
            await interaction.followup.send("❌ O capitão deve estar escalado primeiro.", ephemeral=True)
            return

        user["captain"] = jogador
        save_data(data)
        item = next((i for i in user["inventory"] if i["instance_id"] == jogador), None)
        p = get_player(item["player_id"]) if item else None
        await interaction.followup.send(f"👑 **{p['name'] if p else 'Jogador'}** é o novo capitão!")

    # ── /vender ──────────────────────────────────────────────────────────────────
    @app_commands.command(name="vender", description="Venda um jogador do inventário pelo valor fixo")
    @app_commands.describe(jogador="Jogador que deseja vender")
    @app_commands.autocomplete(jogador=_inv_ac)
    async def vender(self, interaction: discord.Interaction, jogador: str):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))

        item = next((i for i in user["inventory"] if i["instance_id"] == jogador), None)
        if not item:
            await interaction.followup.send("❌ Jogador não encontrado.", ephemeral=True)
            return
        p = get_player(item["player_id"])
        if not p:
            await interaction.followup.send("❌ Jogador inválido.", ephemeral=True)
            return

        user["inventory"].remove(item)
        user["balance"] += p["value"]
        for s, iid in list(user["lineup"].items()):
            if iid == jogador:
                del user["lineup"][s]
        if user["captain"] == jogador:
            user["captain"] = None
        save_data(data)

        embed = discord.Embed(title="💸 Jogador Vendido!", color=0x2ECC71)
        embed.add_field(name="🪪 Jogador", value=p["name"], inline=True)
        embed.add_field(name="💶 Recebido", value=format_money(p["value"]), inline=True)
        embed.add_field(name="💳 Novo Saldo", value=format_money(user["balance"]), inline=True)
        await interaction.followup.send(embed=embed)

    # ── /venderdupli ─────────────────────────────────────────────────────────────
    @app_commands.command(name="venderdupli", description="Venda todas as duplicatas de um jogador pela metade do preço")
    @app_commands.describe(jogador="Jogador do qual vender as duplicatas")
    @app_commands.autocomplete(jogador=_dupli_ac)
    async def vender_dupli(self, interaction: discord.Interaction, jogador: str):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))

        instances = [i for i in user["inventory"] if i["player_id"] == jogador]
        if len(instances) <= 1:
            await interaction.followup.send("❌ Você não tem duplicatas desse jogador (precisa de 2+).", ephemeral=True)
            return

        p = get_player(jogador)
        if not p:
            await interaction.followup.send("❌ Jogador não encontrado.", ephemeral=True)
            return

        lined = set(user["lineup"].values())
        captain = user["captain"]
        keep = next((i["instance_id"] for i in instances if i["instance_id"] in lined or i["instance_id"] == captain), instances[0]["instance_id"])
        dupes = [i for i in instances if i["instance_id"] != keep]
        half = p["value"] // 2
        total = half * len(dupes)

        user["inventory"] = [i for i in user["inventory"] if not (i["player_id"] == jogador and i["instance_id"] in {d["instance_id"] for d in dupes})]
        user["balance"] += total
        save_data(data)

        embed = discord.Embed(title="🔁 Duplicatas Vendidas!", color=0xE67E22)
        embed.add_field(name="🪪 Jogador", value=p["name"], inline=True)
        embed.add_field(name="📦 Cópias Vendidas", value=str(len(dupes)), inline=True)
        embed.add_field(name="💶 Por cópia", value=format_money(half), inline=True)
        embed.add_field(name="💰 Total", value=f"**{format_money(total)}**", inline=True)
        embed.add_field(name="💳 Novo Saldo", value=format_money(user["balance"]), inline=True)
        embed.set_footer(text=f"1 cópia de {p['name']} mantida")
        await interaction.followup.send(embed=embed)

    # ── /comprar ─────────────────────────────────────────────────────────────────
    @app_commands.command(name="comprar", description="Compre um jogador da loja (até classe B+)")
    @app_commands.describe(jogador="Jogador que deseja comprar")
    @app_commands.autocomplete(jogador=_buyable_ac)
    async def comprar(self, interaction: discord.Interaction, jogador: str):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))

        p = get_player(jogador)
        if not p or p["class"] not in BUYABLE_CLASSES:
            await interaction.followup.send("❌ Jogador indisponível na loja.", ephemeral=True)
            return
        if user["balance"] < p["value"]:
            falta = p["value"] - user["balance"]
            await interaction.followup.send(f"❌ Saldo insuficiente! Faltam **{format_money(falta)}**.", ephemeral=True)
            return

        user["balance"] -= p["value"]
        user["inventory"].append({"instance_id": str(uuid.uuid4()), "player_id": p["id"]})
        save_data(data)

        embed = discord.Embed(title="🛒 Compra Realizada!", color=0x3498DB)
        embed.add_field(name="🪪 Jogador", value=p["name"], inline=True)
        embed.add_field(name="💶 Pago", value=format_money(p["value"]), inline=True)
        embed.add_field(name="💳 Saldo Restante", value=format_money(user["balance"]), inline=True)
        await interaction.followup.send(embed=embed)

    # ── /daily ───────────────────────────────────────────────────────────────────
    @app_commands.command(name="daily", description="Resgate sua recompensa diária (7 dias de streak)")
    async def daily(self, interaction: discord.Interaction):
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        now = datetime.now(timezone.utc)
        last_str = user["daily"].get("last_claimed")

        if last_str:
            last_dt = datetime.fromisoformat(last_str)
            since = now - last_dt
            if since < timedelta(hours=24):
                remaining = timedelta(hours=24) - since
                hrs = int(remaining.total_seconds() // 3600)
                mins = int((remaining.total_seconds() % 3600) // 60)
                await interaction.response.send_message(
                    f"⏳ Já resgatou hoje! Próximo daily em **{hrs}h {mins}min**.", ephemeral=True
                )
                return
            if since > timedelta(hours=48):
                user["daily"]["streak"] = 0

        await interaction.response.defer()
        streak = user["daily"].get("streak", 0)

        if streak >= 7:
            user["daily"]["strikes"] = user["daily"].get("strikes", 0) + 1
            user["daily"]["streak"] = 1
            user["daily"]["last_claimed"] = now.isoformat()
            reward = DAILY_REWARDS[0]
            user["balance"] += reward
            save_data(data)
            embed = discord.Embed(title="⚠️ STRIKE! Streak resetado", color=0xFF6B00,
                description=f"Você passou de 7 dias! Strike #{user['daily']['strikes']}. Streak resetado para Dia 1.")
            embed.add_field(name="💰 Recompensa", value=format_money(reward), inline=True)
            embed.add_field(name="💳 Saldo", value=format_money(user["balance"]), inline=True)
            await interaction.followup.send(embed=embed)
            return

        reward = DAILY_REWARDS[streak]
        user["daily"]["streak"] = streak + 1
        user["daily"]["last_claimed"] = now.isoformat()
        user["balance"] += reward
        save_data(data)

        day_num = streak + 1
        bar = "".join("🟩" if i < day_num else "⬜" for i in range(7))
        embed = discord.Embed(title=f"📅 Daily — Dia {day_num}/7", color=0x00D26A)
        embed.add_field(name="💰 Recompensa", value=format_money(reward), inline=True)
        embed.add_field(name="💳 Saldo Total", value=format_money(user["balance"]), inline=True)
        embed.add_field(name="📊 Progresso", value=bar, inline=False)
        footer = f"Próximo dia: {format_money(DAILY_REWARDS[min(day_num, 6)])}" if day_num < 7 else "⚠️ Amanhã será STRIKE se resgatar!"
        embed.set_footer(text=footer)
        await interaction.followup.send(embed=embed)

    # ── /cofre ───────────────────────────────────────────────────────────────────
    @app_commands.command(name="cofre", description="Veja seu saldo atual")
    async def cofre(self, interaction: discord.Interaction):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        embed = discord.Embed(title="🏦 Cofre", color=0xF1C40F)
        embed.add_field(name="💳 Saldo", value=f"**{format_money(user['balance'])}**", inline=False)
        embed.add_field(name="👕 Time", value=user["team_name"], inline=True)
        embed.add_field(name="🏟️ Estádio", value=user["stadium_name"], inline=True)
        embed.add_field(name="📦 Cards", value=str(len(user["inventory"])), inline=True)
        embed.set_footer(text=interaction.user.display_name)
        await interaction.followup.send(embed=embed)

    # ── /nomedotime ──────────────────────────────────────────────────────────────
    @app_commands.command(name="nomedotime", description="Defina o nome do seu clube")
    @app_commands.describe(nome="Nome do time (máx. 30 caracteres)")
    async def nome_do_time(self, interaction: discord.Interaction, nome: str):
        await interaction.response.defer()
        if len(nome) > 30:
            await interaction.followup.send("❌ Nome muito longo! Máximo 30 caracteres.", ephemeral=True)
            return
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        old = user["team_name"]
        user["team_name"] = nome
        save_data(data)
        await interaction.followup.send(f"✅ Nome alterado de **{old}** para **{nome}**!")

    # ── /nomedoestadio ───────────────────────────────────────────────────────────
    @app_commands.command(name="nomedoestadio", description="Defina o nome do seu estádio")
    @app_commands.describe(nome="Nome do estádio (máx. 40 caracteres)")
    async def nome_do_estadio(self, interaction: discord.Interaction, nome: str):
        await interaction.response.defer()
        if len(nome) > 40:
            await interaction.followup.send("❌ Nome muito longo! Máximo 40 caracteres.", ephemeral=True)
            return
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        old = user["stadium_name"]
        user["stadium_name"] = nome
        save_data(data)
        await interaction.followup.send(f"✅ Estádio renomeado de **{old}** para **{nome}**!")

    # ── /mudarformacao ───────────────────────────────────────────────────────────
    @app_commands.command(name="mudarformacao", description="Mude a formação do seu time (escalação é resetada)")
    @app_commands.describe(formacao="Nova formação")
    @app_commands.choices(formacao=[
        app_commands.Choice(name=f, value=f) for f in FORMATIONS
    ])
    async def mudar_formacao(self, interaction: discord.Interaction, formacao: str):
        await interaction.response.defer()
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        if formacao not in FORMATIONS:
            await interaction.followup.send("❌ Formação inválida.", ephemeral=True)
            return
        user["formation"] = formacao
        user["lineup"] = {}
        user["captain"] = None
        save_data(data)
        slots_str = " · ".join(SLOT_LABELS.get(s, s) for s in FORMATIONS[formacao])
        await interaction.followup.send(f"✅ Formação alterada para **{formacao}**!\n{slots_str}\n⚠️ Escalação resetada.")

    # ── /jogarcomia ──────────────────────────────────────────────────────────────
    @app_commands.command(name="jogarcomia", description="Jogue contra a IA e ganhe moedas! (cooldown: 30s)")
    @app_commands.describe(dificuldade="Dificuldade do adversário")
    @app_commands.choices(dificuldade=[
        app_commands.Choice(name=f"{v['emoji']} {v['name']} (OVR {v['ovr']})", value=k)
        for k, v in AI_DIFFICULTIES.items()
    ])
    async def jogar_com_ia(self, interaction: discord.Interaction, dificuldade: str):
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        cd = check_cooldown(user, "last_match", MATCH_COOLDOWN_SECONDS)
        if cd:
            await interaction.response.send_message(
                f"⏳ Aguarde **{cd}s** para jogar outra partida!", ephemeral=True
            )
            return

        diff = AI_DIFFICULTIES.get(dificuldade)
        if not diff:
            await interaction.response.send_message("❌ Dificuldade inválida.", ephemeral=True)
            return

        await interaction.response.defer()

        user_ovr = get_team_ovr(user)
        opp_ovr = diff["ovr"]
        user_slots = get_lineup_names(user)
        opp_names = [random.choice(AI_NAMES) for _ in range(7)]
        opp_slots = {slot: random.choice(opp_names) for slot in FORMATIONS[user.get("formation", "2-3-1")]}
        opp_team = f"FC {random.choice(AI_NAMES)}"
        opp_formation = random.choice(list(FORMATIONS.keys()))

        _, _, events = simulate_match(user_ovr, opp_ovr)

        # Mensagem inicial antes da simulação
        init_embed = discord.Embed(
            title="🏟️ PARTIDA AO VIVO",
            description=f"**{user['team_name']}** vs **{opp_team}**\nCarregando simulação...",
            color=0x3498DB
        )
        await interaction.followup.send(embed=init_embed)

        u_goals, o_goals = await run_live_match(
            interaction=interaction,
            user_team=user["team_name"],
            opp_team=opp_team,
            user_display=interaction.user.display_name,
            opp_display=f"{diff['emoji']} {diff['name']}",
            user_ovr=user_ovr,
            opp_ovr=opp_ovr,
            user_slots=user_slots,
            opp_slots=opp_slots,
            events=events,
            user_formation=user.get("formation", "2-3-1"),
            opp_formation=opp_formation,
            reward_line="",
        )

        won = u_goals > o_goals
        draw = u_goals == o_goals
        if won:
            reward = random.randint(diff["min_reward"], diff["max_reward"])
        elif draw:
            reward = diff["min_reward"] // 2
        else:
            reward = 0

        user["balance"] += reward
        user["last_match"] = datetime.now(timezone.utc).isoformat()
        save_data(data)

        # Editar a mensagem final com prêmio
        won2 = u_goals > o_goals
        draw2 = u_goals == o_goals
        color = 0x00C851 if won2 else (0xFFD700 if draw2 else 0xFF4444)
        result_icon = "🏆 Vitória!" if won2 else ("🤝 Empate!" if draw2 else "💔 Derrota")
        final = discord.Embed(title=f"🏟️ FIM DE JOGO — {result_icon}", color=color)
        final.add_field(
            name="🔵 Seu Time",
            value=f"**{user['team_name']}** ({interaction.user.display_name})\n`OVR {user_ovr}` · {user.get('formation','2-3-1')}",
            inline=True,
        )
        final.add_field(name="⚔️", value="\u200b", inline=True)
        final.add_field(
            name="🔴 Adversário",
            value=f"**{opp_team}** ({diff['emoji']} {diff['name']})\n`OVR {opp_ovr}` · {opp_formation}",
            inline=True,
        )
        final.add_field(
            name="📊 Placar Final",
            value=f"**{user['team_name']} {u_goals} × {o_goals} {opp_team}**",
            inline=False,
        )
        if reward > 0:
            final.add_field(name="💰 Prêmio", value=f"**{format_money(reward)}**", inline=True)
            final.add_field(name="💳 Saldo", value=format_money(user["balance"]), inline=True)
        else:
            final.add_field(name="💳 Saldo", value=format_money(user["balance"]), inline=True)
        await interaction.edit_original_response(embed=final)

    # ── /jogar ───────────────────────────────────────────────────────────────────
    @app_commands.command(name="jogar", description="Desafie outro jogador para uma partida! (cooldown: 30s)")
    @app_commands.describe(adversario="Usuário que deseja desafiar")
    async def jogar(self, interaction: discord.Interaction, adversario: discord.Member):
        data = load_data()
        user = get_user(data, str(interaction.user.id))
        cd = check_cooldown(user, "last_match", MATCH_COOLDOWN_SECONDS)
        if cd:
            await interaction.response.send_message(
                f"⏳ Aguarde **{cd}s** para jogar outra partida!", ephemeral=True
            )
            return

        if adversario.id == interaction.user.id:
            await interaction.response.send_message("❌ Você não pode jogar contra si mesmo!", ephemeral=True)
            return
        if adversario.bot:
            await interaction.response.send_message("❌ Não é possível jogar contra bots. Use `/jogarcomia`.", ephemeral=True)
            return

        await interaction.response.defer()

        opp_user = get_user(data, str(adversario.id))
        user_ovr = get_team_ovr(user)
        opp_ovr = get_team_ovr(opp_user)
        user_slots = get_lineup_names(user)
        opp_slots = get_lineup_names(opp_user)
        user_formation = user.get("formation", "2-3-1")
        opp_formation = opp_user.get("formation", "2-3-1")

        _, _, events = simulate_match(user_ovr, opp_ovr)

        init_embed = discord.Embed(
            title="🏟️ PARTIDA AO VIVO",
            description=f"**{user['team_name']}** vs **{opp_user['team_name']}**\nCarregando simulação...",
            color=0x3498DB
        )
        await interaction.followup.send(embed=init_embed)

        u_goals, o_goals = await run_live_match(
            interaction=interaction,
            user_team=user["team_name"],
            opp_team=opp_user["team_name"],
            user_display=interaction.user.display_name,
            opp_display=adversario.display_name,
            user_ovr=user_ovr,
            opp_ovr=opp_ovr,
            user_slots=user_slots,
            opp_slots=opp_slots,
            events=events,
            user_formation=user_formation,
            opp_formation=opp_formation,
            reward_line="",
        )

        won = u_goals > o_goals
        draw = u_goals == o_goals

        base_prize = 30_000
        if won:
            u_reward = base_prize
            o_reward = 0
        elif draw:
            u_reward = base_prize // 3
            o_reward = base_prize // 3
        else:
            u_reward = 0
            o_reward = base_prize

        user["balance"] += u_reward
        opp_user["balance"] += o_reward
        user["last_match"] = datetime.now(timezone.utc).isoformat()
        save_data(data)

        color = 0x00C851 if won else (0xFFD700 if draw else 0xFF4444)
        result_icon = "🏆 Vitória!" if won else ("🤝 Empate!" if draw else "💔 Derrota")
        final = discord.Embed(title=f"🏟️ FIM DE JOGO — {result_icon}", color=color)
        final.add_field(
            name="🔵 Seu Time",
            value=f"**{user['team_name']}** ({interaction.user.display_name})\n`OVR {user_ovr}` · {user_formation}",
            inline=True,
        )
        final.add_field(name="⚔️", value="\u200b", inline=True)
        final.add_field(
            name="🔴 Adversário",
            value=f"**{opp_user['team_name']}** ({adversario.display_name})\n`OVR {opp_ovr}` · {opp_formation}",
            inline=True,
        )
        final.add_field(
            name="📊 Placar Final",
            value=f"**{user['team_name']} {u_goals} × {o_goals} {opp_user['team_name']}**",
            inline=False,
        )
        final.add_field(name=f"💰 {interaction.user.display_name}", value=format_money(u_reward) if u_reward > 0 else "—", inline=True)
        final.add_field(name=f"💰 {adversario.display_name}", value=format_money(o_reward) if o_reward > 0 else "—", inline=True)
        await interaction.edit_original_response(embed=final)


async def setup(bot: commands.Bot):
    await bot.add_cog(FIFA(bot))
