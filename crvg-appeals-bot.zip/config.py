import os

TOKEN = os.environ.get("DISCORD_BOT_TOKEN", "")

PREFIX = "!"

TEAM_NAME = "Seu Time"

STAFF_ROLE_NAMES = ["Owner", "Co-Owner", "Manager", "Coach", "Staff"]
MOD_ROLE_NAMES = ["Owner", "Co-Owner", "Manager", "Coach", "Staff", "Moderador"]

TICKET_CATEGORY_NAME = "Tickets"
TICKET_LOG_CHANNEL_NAME = "logs-tickets"

# Canal onde as candidaturas serão enviadas
CANDIDATURA_CHANNEL_ID = 1507952644138733638

COLOR_PRIMARY = 0x5865F2
COLOR_SUCCESS = 0x57F287
COLOR_WARNING = 0xFEE75C
COLOR_ERROR   = 0xED4245
COLOR_INFO    = 0x5865F2
COLOR_TEAM    = 0x00B4FF
COLOR_WHITE   = 0xFFFFFF

TICKET_PANEL_DESCRIPTION = (
    "Precisa de ajuda? Quer entrar no time? Tem alguma denúncia?\n"
    "Clique no botão abaixo para abrir um ticket e nossa equipe irá atendê-lo."
)

TICKET_TYPES = [
    {"label": "Suporte Geral",       "emoji": "❓", "value": "geral"},
    {"label": "Denúncia de Jogador", "emoji": "🚨", "value": "denuncia"},
    {"label": "Candidatura ao Time", "emoji": "🏈", "value": "candidatura"},
    {"label": "Pedido de Peneira",   "emoji": "⚽", "value": "peneira"},
    {"label": "Outro",               "emoji": "📋", "value": "outro"},
]
